﻿using MasterDashboard.Entity;
using MasterDashboard.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.BC
{
    public class WsrBC
    {
        public DateTime GetMonday(string selectedDate)
        {
            DateTime d = DateTime.Parse(selectedDate);
            int day = (int)d.DayOfWeek;
            d = d.AddDays(-day + 1);
            return d;
        }

        private List<Entity.Activity> GetWeekActivities(string userId, DateTime startDate)
        {
            List<Entity.Activity> activities = new List<Entity.Activity>();
            try
            {
                var endDate = startDate.AddDays(4);
                using (var context = new MasterDashboardDBEntities())
                {
                    activities = context.Activities.Where(x => x.UserId == userId && x.DateValue >= startDate && x.DateValue <= endDate).ToList();
                }
            }
            catch (Exception)
            {
                activities = new List<Entity.Activity>();
            }
            return activities;
        }

        public List<Model.Activity> GetWeekWSRData(string userId, string selectedDate)
        {
            List<Model.Activity> weekData = new List<Model.Activity>();
            DateTime startDate = new WsrBC().GetMonday(selectedDate);
            var activities = GetWeekActivities(userId, startDate);
            int userLocationId = new UserBC().GetUserLocationByUserId(userId);
            var holidayBC = new HolidayBC();
            for (int i = 0; i <= 4; i++)
            {
                var weekObj = new Model.Activity()
                {
                    UserId = userId,
                   
                    DateString = startDate.AddDays(i).ToShortDateString(),
                    DateValue = startDate.AddDays(i),
                };

                weekObj.HolidayComments = holidayBC.IsDateHoliday(weekObj.DateValue, userLocationId);

                if (string.IsNullOrEmpty(weekObj.HolidayComments))
                    weekObj.IsHoliday = false;
                else
                    weekObj.IsHoliday = true;

                var actItem = activities.Where(x => x.DateValue == weekObj.DateValue);
                if (actItem.Any())
                {
                    var subItem = actItem.First();
                    weekObj.ActivityId = subItem.ActivityId;
                    weekObj.ProjectID = subItem.ProjectId;
                    weekObj.Hours = subItem.Hours;
                    
                    weekObj.Comments = subItem.Comments;
                    weekObj.IsApproved = subItem.IsApproved;
                    weekObj.IsManagerApproved = subItem.IsManagerApproved;
                }
                weekData.Add(weekObj);
            }
            return weekData;
        }

        public long AddActivity(Model.Activity activity)
        {
            long activityID = 0;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var projectAllocationID = context.ProjectAllocations.FirstOrDefault(x => x.UserID == activity.UserId && x.StartDate <= activity.DateValue && x.EndDate >= activity.DateValue && x.ProjectID==activity.ProjectID).ProjectAllocationID;
                    activity.ProjectAllocationId = projectAllocationID;
                    var newItem = ModelToEntity.ActivityEntity(activity);
                    context.Activities.Add(newItem);
                    context.SaveChanges();
                    activityID = newItem.ActivityId;
                }
            }
            catch (Exception ex)
            {
                throw ex;
                     
            }
            return activityID;
        }

        public bool UpdateActivity(Model.Activity activity)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.Activities.First(x => x.ActivityId == activity.ActivityId);
                    item.ProjectId = activity.ProjectID;
                    //item.ProjectAllocationId = activity.ProjectAllocationId;
                    item.Hours = activity.Hours;
                    item.Comments = activity.Comments;

                    context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }

        public bool ApproveWeekActivity(string userId, DateTime mondayDate)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var endDate = mondayDate.AddDays(4);
                    var activities = context.Activities.Where(x => x.UserId == userId && x.DateValue >= mondayDate && x.DateValue <= endDate).ToList();
                    foreach (var item in activities)
                    {
                        item.IsApproved = true;
                        context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    }
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }

        public bool ManagerApproveWeekActivity(string userId, DateTime mondayDate)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var endDate = mondayDate.AddDays(4);
                    var activities = context.Activities.Where(x => x.UserId == userId && x.DateValue >= mondayDate && x.DateValue <= endDate).ToList();
                    foreach (var item in activities)
                    {
                        item.IsManagerApproved = true;
                        context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    }
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }

        public bool ApproveAllForWeek(DateTime mondayDate)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var endDate = mondayDate.AddDays(4);
                    var activities = context.Activities.Where(x => x.DateValue >= mondayDate && x.DateValue <= endDate).ToList();
                    foreach (var item in activities)
                    {
                        item.IsManagerApproved = true;
                        context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    }
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }
    }
}
