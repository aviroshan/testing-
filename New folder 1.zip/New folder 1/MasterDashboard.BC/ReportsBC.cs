﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MasterDashboard.Entity;
using System.Data;


namespace MasterDashboard.BC
{
    public class ReportsBC
    {
        private MasterDashboardDBEntities db = new MasterDashboardDBEntities();
        public List<Model.Project> GetProjects()
        {
            List<Model.Project> projects = new List<Model.Project>();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var projectDomains = context.ProjectDomains.ToList();
                    var projectPrograms = context.ProjectPrograms.ToList();

                    context.Projects.ToList().ForEach(x =>
                    {
                        projects.Add(new Model.Project()
                        {
                            ProjectID = x.ProjectID,
                            ProjectName = x.ProjectName,
                            ProgramID = x.ProgramID,

                        });
                    });

                    projects.ForEach(pt =>
                    {
                        pt.ProgramName = projectPrograms.FirstOrDefault(pd => pd.ProgramID == pt.ProgramID).ProgramName;
                        pt.DomainID = projectPrograms.FirstOrDefault(pd => pd.ProgramID == pt.ProgramID).DomainID;
                        pt.DomainName = projectDomains.FirstOrDefault(pd => pd.DomainID == pt.DomainID).DomainName;
                    });

                }
            }
            catch (Exception)
            {
                projects = new List<Model.Project>();
            }
            return projects;
        }
      
    }
} 
