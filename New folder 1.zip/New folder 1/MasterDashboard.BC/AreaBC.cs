﻿using System;
using MasterDashboard.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.BC
{
    public class AreaBC
    {
        public int AddArea(Model.Area area)
        {
            int areaId = 0;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var newItem = new Entity.Area()
                    {
                        AreaId = area.AreaId,
                        AreaName = area.AreaName
                    };
                    context.Areas.Add(newItem);
                    context.SaveChanges();
                    areaId = newItem.AreaId;
                }
            }
            catch (Exception)
            {
                areaId = 0;
            }
            return areaId;
        }

        public List<Model.Area> GetAreas()
        {
            List<Model.Area> areas = new List<Model.Area>();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                

                    context.Areas.ToList().ForEach(x =>
                    {
                        areas.Add(new Model.Area()
                        {
                            AreaId = x.AreaId,
                            AreaName = x.AreaName,
                            

                        });
                    });

                   
                }
            }
            catch (Exception)
            {
                areas = new List<Model.Area>();
            }
            return areas;
        }

        public bool UpdateArea(Model.Area area)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.Areas.First(x => x.AreaId == area.AreaId);              
                    item.AreaName = area.AreaName;
                    context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }
    }
}
