﻿using MasterDashboard.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model = MasterDashboard.Model;

namespace MasterDashboard.BC
{
    public class ProjectBC
    {
        public List<Model.ProjectProgram> GetProjectPrograms()
        {
            List<Model.ProjectProgram> areas = new List<Model.ProjectProgram>();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var projectDomains = context.ProjectDomains.ToList();

                    context.ProjectPrograms.ToList().ForEach(x =>
                    {
                        areas.Add(new Model.ProjectProgram()
                        {
                            ProgramID = x.ProgramID,
                            ProgramName = x.ProgramName,
                            DomainID = x.DomainID,
                            DomainName = projectDomains.FirstOrDefault(y => y.DomainID == x.DomainID).DomainName
                        });
                    });
                }
            }
            catch (Exception)
            {
                areas = new List<Model.ProjectProgram>();
            }
            return areas;
        }

        public List<Model.ProjectDomain> GetProjectDomains()
        {
            List<Model.ProjectDomain> areas = new List<Model.ProjectDomain>();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    context.ProjectDomains.ToList().ForEach(x =>
                    {
                        areas.Add(new Model.ProjectDomain()
                        {
                            DomainID = x.DomainID,
                            DomainName = x.DomainName,
                        });
                    });
                }
            }
            catch (Exception)
            {
                areas = new List<Model.ProjectDomain>();
            }
            return areas;
        }

        public List<Model.Project> GetProjects()
        {
            List<Model.Project> projects = new List<Model.Project>();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var projectDomains = context.ProjectDomains.ToList();
                    var projectPrograms = context.ProjectPrograms.ToList();

                    context.Projects.ToList().ForEach(x =>
                    {
                        projects.Add(new Model.Project()
                        {
                            ProjectID = x.ProjectID,
                            ProjectName = x.ProjectName,
                            ProgramID = x.ProgramID,
                            
                        });
                    });

                    projects.ForEach(pt =>
                    {
                        pt.ProgramName = projectPrograms.FirstOrDefault(pd => pd.ProgramID == pt.ProgramID).ProgramName;
                        pt.DomainID = projectPrograms.FirstOrDefault(pd => pd.ProgramID == pt.ProgramID).DomainID;
                        pt.DomainName = projectDomains.FirstOrDefault(pd => pd.DomainID == pt.DomainID).DomainName;
                    });

                }
            }
            catch (Exception)
            {
                projects = new List<Model.Project>();
            }
            return projects;
        }

        #region Project
        public int AddProject(Model.Project project)
        {
            int projectID = 0;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var newItem = new Entity.Project()
                    {
                        ProgramID = project.ProgramID,
                        ProjectName = project.ProjectName
                    };
                    context.Projects.Add(newItem);
                    context.SaveChanges();
                    projectID = newItem.ProjectID;
                }
            }
            catch (Exception)
            {
                projectID = 0;
            }
            return projectID;
        }

        public bool UpdateProject(Model.Project project)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.Projects.First(x => x.ProjectID == project.ProjectID);
                    item.ProgramID = project.ProgramID;
                    item.ProjectName = project.ProjectName;
                    context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }

        public bool DeleteProject(int projectID)
        {
            bool isDeleted = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.Projects.First(x => x.ProjectID == projectID);
                    context.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                    context.SaveChanges();
                    isDeleted = true;
                }
            }
            catch (Exception)
            {
                isDeleted = false;
            }
            return isDeleted;
        }
        #endregion

        #region Program
        public int AddProgram(Model.ProjectProgram program)
        {
            int programID = 0;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var newItem = new Entity.ProjectProgram()
                    {
                        ProgramName = program.ProgramName,
                        DomainID = program.DomainID
                    };
                    context.ProjectPrograms.Add(newItem);
                    context.SaveChanges();
                    programID = newItem.ProgramID;
                }
            }
            catch (Exception)
            {
                programID = 0;
            }
            return programID;
        }

        public bool UpdateProgram(Model.ProjectProgram program)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.ProjectPrograms.First(x => x.ProgramID == program.ProgramID);
                    item.ProgramID = program.ProgramID;
                    item.ProgramName = program.ProgramName;
                    item.DomainID = program.DomainID;
                    context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }

        public bool DeleteProgram(int programID)
        {
            bool isDeleted = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.ProjectPrograms.First(x => x.ProgramID == programID);
                    context.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                    context.SaveChanges();
                    isDeleted = true;
                }
            }
            catch (Exception)
            {
                isDeleted = false;
            }
            return isDeleted;
        }
        #endregion

        #region Domain
        public int AddDomain(Model.ProjectDomain domain)
        {
            int domainID = 0;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var newItem = new Entity.ProjectDomain()
                    {
                        DomainName = domain.DomainName
                    };
                    context.ProjectDomains.Add(newItem);
                    context.SaveChanges();
                    domainID = newItem.DomainID;
                }
            }
            catch (Exception)
            {
                domainID = 0;
            }
            return domainID;
        }

        public bool UpdateDomain(Model.ProjectDomain domain)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.ProjectDomains.First(x => x.DomainID == domain.DomainID);
                    item.DomainID = domain.DomainID;
                    item.DomainName = domain.DomainName;
                    context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }

        public bool DeleteDomain(int domainID)
        {
            bool isDeleted = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.ProjectPrograms.First(x => x.DomainID == domainID);
                    context.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                    context.SaveChanges();
                    isDeleted = true;
                }
            }
            catch (Exception)
            {
                isDeleted = false;
            }
            return isDeleted;
        }
        #endregion
    }
}
