﻿using MasterDashboard.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.BC
{
    public class ProjectAllocationBC
    {
        public List<Model.ProjectAllocation> GetAllProjectAllocation()
        {
            List<Model.ProjectAllocation> projectAllocations = new List<Model.ProjectAllocation>();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var projects = context.Projects.ToList();
                    var projectAllocationTypes = context.ProjectAllocationTypes.ToList();
                    var users = context.UserProfiles.ToList();

                    context.ProjectAllocations.ToList().ForEach(x =>
                    {
                        projectAllocations.Add(new Model.ProjectAllocation()
                        {
                            ProjectAllocationID = x.ProjectAllocationID,
                            UserID = x.UserID,
                            UserName = users.FirstOrDefault(y => y.UserId == x.UserID).Name,
                            ProjectID = x.ProjectID,
                            ProjectName = projects.FirstOrDefault(y => y.ProjectID == x.ProjectID).ProjectName,
                            StartDate = x.StartDate,
                            EndDate = x.EndDate,
                            Rate=x.Rate.GetValueOrDefault(),
                            AllocationTypeID = x.AllocationTypeID,
                            AllocationTypeName = projectAllocationTypes.FirstOrDefault(y => y.ProjectAllocationTypeID == x.AllocationTypeID).AllocationTypeName
                        });
                    });
                }
            }
            catch (Exception)
            {
                projectAllocations = new List<Model.ProjectAllocation>();
            }
            return projectAllocations;
        }

        public Model.ProjectAllocation GetProjectAllocationByID(int projectAllocationID)
        {
            Model.ProjectAllocation projectAllocation = new Model.ProjectAllocation();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var projects = context.Projects.ToList();
                    var projectAllocationTypes = context.ProjectAllocationTypes.ToList();
                    var users = context.UserProfiles.ToList();

                    var x = context.ProjectAllocations.FirstOrDefault(y => y.ProjectAllocationID == projectAllocationID);
                    projectAllocation = new Model.ProjectAllocation()
                    {
                        ProjectAllocationID = x.ProjectAllocationID,
                        UserID = x.UserID,
                        UserName = users.FirstOrDefault(y => y.UserId == x.UserID).Name,
                        ProjectID = x.ProjectID,
                        ProjectName = projects.FirstOrDefault(y => y.ProjectID == x.ProjectID).ProjectName,
                        StartDate = x.StartDate,
                        EndDate = x.EndDate,
                        Rate = x.Rate.GetValueOrDefault(),
                        AllocationTypeID = x.AllocationTypeID,
                        AllocationTypeName = projectAllocationTypes.FirstOrDefault(y => y.ProjectAllocationTypeID == x.AllocationTypeID).AllocationTypeName
                    };
                };
            }
            catch (Exception)
            {
                projectAllocation = new Model.ProjectAllocation();
            }
            return projectAllocation;
        }

        public List<Model.ProjectAllocation> GetProjetAllocationByPredicate(Predicate<Entity.ProjectAllocation> predicate)
        {
            List<Model.ProjectAllocation> projectAllocations = new List<Model.ProjectAllocation>();
            Func<Entity.ProjectAllocation, bool> condition;
            if (predicate != null)
                condition = new Func<ProjectAllocation, bool>(predicate);
            else
                condition = new Func<ProjectAllocation, bool>(a => a != null);

            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    predicate = xy => xy != null;

                    var projects = context.Projects.ToList();
                    var projectAllocationTypes = context.ProjectAllocationTypes.ToList();
                    var users = context.UserProfiles.ToList();

                    context.ProjectAllocations.Where(condition).ToList().ForEach(x =>
                    {
                        projectAllocations.Add(new Model.ProjectAllocation()
                        {
                            ProjectAllocationID = x.ProjectAllocationID,
                            UserID = x.UserID,
                            UserName = users.FirstOrDefault(y => y.UserId == x.UserID).Name,
                            ProjectID = x.ProjectID,
                            ProjectName = projects.FirstOrDefault(y => y.ProjectID == x.ProjectID).ProjectName,
                            StartDate = x.StartDate,
                            EndDate = x.EndDate,
                            Rate = x.Rate.GetValueOrDefault(),
                            AllocationTypeID = x.AllocationTypeID,
                            AllocationTypeName = projectAllocationTypes.FirstOrDefault(y => y.ProjectAllocationTypeID == x.AllocationTypeID).AllocationTypeName
                        });
                    });
                }
            }
            catch (Exception)
            {
                projectAllocations = new List<Model.ProjectAllocation>();
            }
            return projectAllocations;
        }

        public int AddProjectAllocation(Model.ProjectAllocation allocation)
        {
            int allocationID = 0;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var newItem = new Entity.ProjectAllocation()
                    {
                        ProjectID = allocation.ProjectID,
                        UserID = allocation.UserID,
                        StartDate = DateTime.Parse(allocation.StartDate.ToString()),
                        EndDate = DateTime.Parse(allocation.EndDate.ToString()),
                        Rate=allocation.Rate,
                        AllocationTypeID = allocation.AllocationTypeID
                    };
                    context.ProjectAllocations.Add(newItem);
                    context.SaveChanges();
                    allocationID = newItem.ProjectAllocationID;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return allocationID;
        }

        public bool UpdateProjectAllocation(Model.ProjectAllocation allocation)
        {
            bool isUpdated = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.ProjectAllocations.First(x => x.ProjectAllocationID == allocation.ProjectAllocationID);
                    item.ProjectID = allocation.ProjectID;
                    item.UserID = allocation.UserID;
                    item.StartDate = allocation.StartDate;
                    item.EndDate = allocation.EndDate;
                    item.Rate = allocation.Rate;
                    item.AllocationTypeID = allocation.AllocationTypeID;
                    context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                    context.SaveChanges();
                    isUpdated = true;
                }
            }
            catch (Exception)
            {
                isUpdated = false;
            }
            return isUpdated;
        }

        public bool DeleteProjectAllocation(int allocationID)
        {
            bool isDeleted = false;
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    var item = context.ProjectAllocations.First(x => x.ProjectAllocationID == allocationID);
                    context.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                    context.SaveChanges();
                    isDeleted = true;
                }
            }
            catch (Exception)
            {
                isDeleted = false;
            }
            return isDeleted;
        }
    }
}
