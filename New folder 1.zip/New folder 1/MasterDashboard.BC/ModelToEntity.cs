﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.BC
{
    public static class ModelToEntity
    {
        public static Entity.Activity ActivityEntity(Model.Activity activity)
        {
            var newItem = new Entity.Activity()
            {
                ActivityId = activity.ActivityId,
                UserId = activity.UserId,
                DateValue = activity.DateValue,
                ProjectId = activity.ProjectID,
                ProjectAllocationId=activity.ProjectAllocationId,
                Hours = activity.Hours,
                Comments = activity.Comments,
                IsApproved = activity.IsApproved,
                IsManagerApproved = activity.IsManagerApproved
            };
            return newItem;
        }

        public static Entity.ProjectAllocation ProjectAllocation(Model.ProjectAllocation allocation)
        {
            var newItem = new Entity.ProjectAllocation()
            {
                ProjectAllocationID = allocation.ProjectAllocationID,
                ProjectID = allocation.ProjectID,
                UserID = allocation.UserID,
                StartDate = allocation.StartDate,
                EndDate = allocation.EndDate,
                AllocationTypeID = allocation.AllocationTypeID
            };
            return newItem;
        }
    }
}
