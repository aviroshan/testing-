﻿using MasterDashboard.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.BC
{
    public class ProjectAllocationTypeBC
    {
        public List<Model.ProjectAllocationType> GetAllProjectAllocationTypes()
        {
            List<Model.ProjectAllocationType> projectAllocationTypes = new List<Model.ProjectAllocationType>();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    context.ProjectAllocationTypes.ToList().ForEach(x =>
                    {
                        projectAllocationTypes.Add(new Model.ProjectAllocationType()
                        {
                            AllocationTypeID = x.ProjectAllocationTypeID,
                            AllocationTypeName = x.AllocationTypeName,
                            Description = x.Description
                        });
                    });
                }
            }
            catch (Exception)
            {
                projectAllocationTypes = new List<Model.ProjectAllocationType>();
            }
            return projectAllocationTypes;
        }
    }
}
