﻿using MasterDashboard.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.BC
{
    public class UserBC
    {
        public List<Model.User> GetUsers()
        {
            List<Model.User> users = new List<Model.User>();
            var locations = new LocationBC().GetLocations();
            try
            {
                using (var context = new MasterDashboardDBEntities())
                {
                    context.UserProfiles.ToList().ForEach(x =>
                    {
                        users.Add(new Model.User()
                        {
                            UserID = x.UserId,
                            CognizantID = x.CognizantId,
                            Name = x.Name,
                            EmailID = x.EmailID,
                            LocationID = x.LocationId,
                            Password = x.Password,
                            LocationName = locations.First(xy => xy.LocationID == x.LocationId).LocationName
                        });
                    });
                }
            }
            catch (Exception ex)
            {
                users = new List<Model.User>();
            }
            return users;
        }

        public int GetUserLocationByUserId(string userId)
        {
            int locationID = -1;
            using (var context = new MasterDashboardDBEntities())
            {
                locationID = context.UserProfiles.FirstOrDefault(x => x.UserId == userId).LocationId;
            }
            return locationID;
        }

        public bool AddUser(Model.User user)
        {
            bool isAdded = false;
            using (var context = new MasterDashboardDBEntities())
            {
                var newItem = new Entity.UserProfile()
                {
                    UserId = user.UserID,
                    Name = user.Name,
                    CognizantId = user.CognizantID,
                    EmailID = user.EmailID,
                    Password = user.Password,
                    LocationId = user.LocationID,
                };
                context.UserProfiles.Add(newItem);
                context.SaveChanges();
                isAdded = true;
            }
            return isAdded;
        }

        public bool UpdateUser(Model.User user)
        {
            bool isUpdated = false;
            using (var context = new MasterDashboardDBEntities())
            {
                var item = context.UserProfiles.First(x => x.UserId == user.UserID);
                item.CognizantId = user.CognizantID;
                item.Name = user.Name;
                item.EmailID = user.EmailID;
                item.Password = user.Password;
                item.LocationId = user.LocationID;
                context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();
                isUpdated = true;
            }
            return isUpdated;
        }

        public bool DeleteUser(string userId)
        {
            bool isDeleted = false;
            using (var context = new MasterDashboardDBEntities())
            {
                var item = context.UserProfiles.First(x => x.UserId == userId);
                context.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                context.SaveChanges();
                isDeleted = true;
            }
            return isDeleted;
        }
    }
}
