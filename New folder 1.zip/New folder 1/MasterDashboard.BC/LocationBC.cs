﻿using MasterDashboard.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.BC
{
    public class LocationBC
    {
        public List<Model.Location> GetLocations()
        {
            List<Model.Location> locations = new List<Model.Location>();
            using (var context = new MasterDashboardDBEntities())
            {
                var allLocations = context.WorkLocations.Where(x =>x.LocationName != "All").ToList();
                allLocations.ForEach(x =>
                {
                    locations.Add(new Model.Location()
                    {
                        LocationID = x.LocationID,
                        LocationName = x.LocationName,
                        IsHolidayConnected = context.Holidays.Where(xy => xy.LocationID == x.LocationID).Any()
                    });
                });
            }
            return locations;
        }


        public int AddLocation(Model.Location location)
        {
            int LocationID = 0;
            using (var context = new MasterDashboardDBEntities())
            {
                var newItem = new Entity.WorkLocation()
                {
                    LocationName = location.LocationName
                };
                context.WorkLocations.Add(newItem);
                context.SaveChanges();
                LocationID = newItem.LocationID;
            }
            return LocationID;
        }

        public bool UpdateLocation(Model.Location location)
        {
            bool isUpdated = false;
            using (var context = new MasterDashboardDBEntities())
            {
                var item = context.WorkLocations.First(x => x.LocationID == location.LocationID);
                item.LocationName = location.LocationName;
                context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();
                isUpdated = true;
            }
            return isUpdated;
        }

        public bool DeleteLocation(int locationID)
        {
            bool isDeleted = false;
            using (var context = new MasterDashboardDBEntities())
            {
                var item = context.WorkLocations.First(x => x.LocationID == locationID);
                context.Entry(item).State = System.Data.Entity.EntityState.Deleted;
                context.SaveChanges();
                isDeleted = true;
            }
            return isDeleted;
        }
    }
}
