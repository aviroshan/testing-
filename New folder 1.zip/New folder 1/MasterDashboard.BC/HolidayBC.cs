﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MasterDashboard.Entity;

namespace MasterDashboard.BC
{
    public class HolidayBC
    {
        public List<Model.Holiday> GetAllHolidays(int year, int locationID = 0)
        {
            List<Model.Holiday> holidays = new List<Model.Holiday>();
            var allHolidays = new List<Entity.Holiday>();
            using (var context = new MasterDashboardDBEntities())
            {
                if (locationID == 0)
                    allHolidays = context.Holidays.Where(x => x.DateValue.Year == year).ToList();
                else
                    allHolidays = context.Holidays.AsNoTracking().Where(x => x.LocationID == locationID && x.DateValue.Year == year).ToList();
            }

            allHolidays.ForEach(x =>
            {
                holidays.Add(new Model.Holiday()
                {
                    IsHoliday = true,
                    HolidayID = x.HolidayID,
                    DateValue = x.DateValue,
                    DateString = x.DateValue.ToShortDateString(),
                    LocationID = x.LocationID,
                    Comments = x.Comments

                });
            });
            return holidays;
        }

        public bool AddHoliday(Model.Holiday holiday)
        {
            bool isInserted = false;
            using (var context = new MasterDashboardDBEntities())
            {
                context.Holidays.Add(new Entity.Holiday()
                {
                    DateValue = holiday.DateValue,
                    LocationID = holiday.LocationID,
                    Comments = holiday.Comments
                });
                context.SaveChanges();
                isInserted = true;
            }
            return isInserted;
        }

        public bool UpdateHoliday(Model.Holiday holiday)
        {
            bool isUpdated = false;
            using (var context = new MasterDashboardDBEntities())
            {
                var item = context.Holidays.First(x => x.HolidayID == holiday.HolidayID);
                item.LocationID = holiday.LocationID;
                item.Comments = holiday.Comments;
                context.Entry(item).State = System.Data.Entity.EntityState.Modified;
                context.SaveChanges();
                isUpdated = true;
            }
            return isUpdated;
        }

        public bool DeleteHoliday(int holidayID)
        {
            bool isDeleted = false;
            using (var context = new MasterDashboardDBEntities())
            {
                var holidayItem = context.Holidays.First(x => x.HolidayID == holidayID);
                context.Entry(holidayItem).State = System.Data.Entity.EntityState.Deleted;
                context.SaveChanges();
                isDeleted = true;
            }
            return isDeleted;
        }

        //Returns Holiday Comments or empty string
        public string IsDateHoliday(DateTime date, int locationID)
        {
            string holiday = string.Empty;
            using (var context = new MasterDashboardDBEntities())
            {
                //Check National Holidays First
                if (context.Holidays.Where(x => x.DateValue == date && x.LocationID == 0).Any())
                    holiday = context.Holidays.First(x => x.DateValue == date && x.LocationID == 0).Comments;

                //Check Regional Holidays if no national holiday
                if(string.IsNullOrEmpty(holiday) && locationID != 0)
                {
                    if (context.Holidays.Where(x => x.DateValue == date && x.LocationID == locationID).Any())
                        holiday = context.Holidays.First(x => x.DateValue == date && x.LocationID == locationID).Comments;
                }
            }
            return holiday;
        }

        public List<Model.Holiday> GetHolidaysInWeek(DateTime monday, int locationID)
        {
            List<Model.Holiday> weekHolidays = new List<Model.Holiday>();
            DateTime date = DateTime.Now;

            using (var context = new MasterDashboardDBEntities())
            {
                for (int i = 0; i < 5; i++)
                {
                    date = monday.AddDays(i);
                    weekHolidays.Add(new Model.Holiday()
                    {
                        DateValue = date,
                        IsHoliday = context.Holidays.Where(x => x.DateValue == date && x.LocationID == locationID).Any(),
                        Comments = context.Holidays.Where(x => x.DateValue == date && x.LocationID == locationID)?.FirstOrDefault()?.Comments
                    });
                }
            }
            return weekHolidays;
        }

        /// <summary>
        /// Get All Holidays for each location (or) Location-wise Holidays
        /// </summary>
        /// <param>int LocationID</param>
        public List<Model.Location> GetLocationWiseHolidays(int year, int locationID = 0)
        {
            var locations = new List<Model.Location>();
            locations = new LocationBC().GetLocations();

            if (locationID != 0)
                locations = new LocationBC().GetLocations().Where(x => x.LocationID == locationID).ToList();

            var holidays = new HolidayBC().GetAllHolidays(year, locationID);

            foreach (var loc in locations)
            {
                var locHoliday = holidays.Where(xy => xy.LocationID == loc.LocationID).ToList();
                locations.Add(new Model.Location()
                {
                    LocationID = loc.LocationID,
                    LocationName = loc.LocationName,
                    Holidays = locHoliday
                });
            }
            return locations;
        }
    }
}
