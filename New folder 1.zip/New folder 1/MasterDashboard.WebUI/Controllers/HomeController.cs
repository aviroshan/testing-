﻿using MasterDashboard.BC;
using MasterDashboard.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MasterDashboard.Entity;

namespace MasterDashboard.WebUI.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(MasterDashboard.Entity.UserProfile objUser)
        {
            if (ModelState.IsValid)
            {
                using (MasterDashboardDBEntities db = new MasterDashboardDBEntities())
                {
                    var obj = db.UserProfiles.Where(a => a.UserId.Equals(objUser.UserId) && a.Password.Equals(objUser.Password)).FirstOrDefault();
                    if (obj != null)
                    {
                        Session["Password"] = obj.Password.ToString();
                        Session["UserId"] = obj.UserId.ToString();
                        return RedirectToAction("Index");
                    }
                    else
                        return RedirectToAction("Login");

                }
            }
            return View(objUser);
        }

        public ActionResult ItemsIndex()
        {
            return View();
        }

        public JsonResult GetHomeScreenItems()
        {
            var projects = new[]{
                new{ Name = "Index", Description = "Search All Functionalities.", Click= Url.Action("ItemsIndex", "Home", new { area = "" }).ToString()},
                new{ Name = "PMP", Description = "Project Management Portal.", Click= Url.Action("Index", "PMP", new { area = "PMP" }).ToString()},
                new{ Name = "Timesheet", Description = "Weekly Timesheet Tracker.", Click = Url.Action("Index", "WSR", new { area = "WSR" }).ToString()},
                new{ Name = "DSR", Description = "Daily Status Tracker.", Click= Url.Action("Index", "DSR", new { area = "DSR" }).ToString()},
                new{ Name = "Reports", Description = "For maintaining CSR.", Click= Url.Action("Index", "Reports", new { area = "Reports" }).ToString()},
                new{ Name = "User Profile", Description = "For maintaining FSR.", Click= Url.Action("Index", "WST", new { area = "" }).ToString()},
            };
            return Json(projects, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetMasterDashboardIndices()
        {
            List<MasterDashboardIndex> result = new List<MasterDashboardIndex>();
            result.Add(new MasterDashboardIndex()
            {
                Name = "Weekly Status Tracker",
                Click = Url.Action("Index", "WSR", new { area = "WSR" }).ToString(),
                SubItems = new List<MasterDashboardIndex>(),
                RoleName = "BasicUser"
            });
            result.Add(new MasterDashboardIndex()
            {
                Name = "Daily Status Tracker",
                Click = Url.Action("Index", "DSR", new { area = "DSR" }).ToString(),
                SubItems = new List<MasterDashboardIndex>(),
                RoleName = "BasicUser"
            });

            #region PMP
            var pmpItem = new MasterDashboardIndex()
            {
                Name = "Project Management Portal",
                Click = Url.Action("Index", "PMP", new { area = "PMP" }).ToString(),
                SubItems = new List<MasterDashboardIndex>(),
                RoleName = "Admin"
            };
            pmpItem.SubItems.Add(new MasterDashboardIndex()
            {
                Name = "Projects & Areas",
                Click = Url.Action("ProjectArea", "PMP", new { area = "PMP" }).ToString(),
                RoleName = "Admin"
            });
            pmpItem.SubItems.Add(new MasterDashboardIndex()
            {
                Name = "Location",
                Click = Url.Action("Location", "PMP", new { area = "PMP" }).ToString(),
                RoleName = "Admin"
            });
            pmpItem.SubItems.Add(new MasterDashboardIndex()
            {
                Name = "Holiday",
                Click = Url.Action("Holiday", "PMP", new { area = "PMP" }).ToString(),
                RoleName = "Admin"
            });
            pmpItem.SubItems.Add(new MasterDashboardIndex()
            {
                Name = "Team Members Profile",
                Click = Url.Action("TeamMember", "PMP", new { area = "PMP" }).ToString(),
                RoleName = "Admin"
            });
            result.Add(pmpItem);
            #endregion

            result.Add(new MasterDashboardIndex()
            {
                Name = "Reports",
                Click = Url.Action("Index", "WSR", new { area = "WSR" }).ToString(),
                SubItems = new List<MasterDashboardIndex>(),
                RoleName = "Admin"
            });
            result.Add(new MasterDashboardIndex()
            {
                Name = "Reports",
                Click = Url.Action("SimpleReport", "Reports", new { area = "PMP" }).ToString(),
                SubItems = new List<MasterDashboardIndex>(),
                RoleName = "Admin"
            });
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}
