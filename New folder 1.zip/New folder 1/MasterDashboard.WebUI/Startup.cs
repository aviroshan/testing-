﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MasterDashboard.WebUI.Startup))]
namespace MasterDashboard.WebUI
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
