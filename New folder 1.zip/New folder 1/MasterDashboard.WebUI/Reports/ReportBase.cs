﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MasterDashboard.WebUI.Reports
{
    public class ReportBase : Controller
    {
        /// <summary>
        /// GetReportOutputStream
        /// </summary>
        /// <param name="rdlcPath"></param>
        /// <param name="dataSourceList"></param>
        /// <param name="reportType"></param>
        /// <param name="fileName"></param>
        /// <param name="reportParameters"></param>
        /// <returns></returns>
        public Stream GetReportOutputStream(string rdlcPath, Dictionary<string, object> dataSourceList, ReportType reportType, string fileName, Dictionary<string, string> reportParameters = null)
        {
            var rv = new ReportViewer();
            rv.Reset();
            rv.LocalReport.ReportPath = rdlcPath;
            rv.LocalReport.DataSources.Clear();
            try
            {
                foreach (var kv in dataSourceList)
                {
                    ReportDataSource rds = new ReportDataSource(kv.Key, kv.Value);
                    rv.LocalReport.DataSources.Add(rds);
                }

                //if (reportParameters != null)
                //{
                //    var rptParams = new List<ReportParameter>();
                //    foreach (var kv in reportParameters)
                //        rptParams.Add(new ReportParameter(kv.Key, kv.Value));

                //    rv.LocalReport.SetParameters(rptParams);
                //}

                rv.LocalReport.Refresh();

                byte[] streamBytes = null;
                string mimeType = "";
                string encoding = "";
                string filenameExtension = "";
                string[] streamids = null;
                Warning[] warnings = null;

                streamBytes = rv.LocalReport.Render(reportType.ToString(), null, out mimeType, out encoding, out filenameExtension, out streamids, out warnings);

                //var response = Response == null ? new HttpResponseMessage(HttpStatusCode.OK) : Response;
                var response = System.Web.HttpContext.Current.Response;

                // Now that you have all the bytes representing the PDF report, buffer it and send it to the client.
                response.Buffer = true;
                response.Clear();
                response.ContentType = mimeType;
                response.AddHeader("Content-Length", streamBytes.Length.ToString());
                response.AddHeader("content-disposition", "attachment; filename=" + fileName + "." + filenameExtension);
                response.BinaryWrite(streamBytes); // create the file
                response.Flush(); // send it to the client to download
                response.End();

                return response.OutputStream;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        public enum ReportType
        {
            EXCELOPENXML,
            PDF,
            WORD
        }
    }
}