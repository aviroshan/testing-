﻿/// <reference path="../Libs/angular.min.js" />

// **************************************************
// *** My AngularJS Directive(s) Application ********
// **************************************************

// Module specific configuration
var app = angular.module("myApp", [
                                     'httpPostFix',
                                     'angularjs-dropdown-multiselect',
                                     'angularUtils.directives.dirPagination'
                                  ]
                         );



