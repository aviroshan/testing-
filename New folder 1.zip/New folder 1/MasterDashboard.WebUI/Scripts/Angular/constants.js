﻿/// <reference path="angularModule.js" />

(function () {
    var appSettings = sessionStorage.getItem('appSettings');
    if (appSettings == null) {
        $.ajax({
            url: '../scripts/angular/configKey.json',
            async: false,
            dataType: 'json',
            success: function (response) {
                app.constant('appSettings', response);
                sessionStorage.setItem('appSettings', JSON.stringify(response));
            },
            error: function (data) {
                alert('error geettin gconstants');
            }
        });
    }
    else {
        var config = sessionStorage.getItem('appSettings');
        app.constant('appSettings', JSON.parse(config));
    }
})();

app.constant("MasterConstant", {
    PageTitle: "Master Dashboard",
    ShortTitle: "Dashboard"
});

app.run(function ($rootScope, MasterConstant) {
    $rootScope.MasterConstant = MasterConstant;
    $rootScope.userName = function () {
        return sessionStorage.getItem("LoggedUserName");
    };
    $rootScope.password = function () {
        return sessionStorage.getItem("LoggedUserPassword");
    };
});