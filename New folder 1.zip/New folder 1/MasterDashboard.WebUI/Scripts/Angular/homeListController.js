﻿/// <reference path="angularModule.js" />

app.controller("homeListController", function ($scope, $rootScope, appSettings, apiService, $filter) {
    /*-----------------Alert Modal Variables and Data loading---------------------------*/
    $scope.data_waiting = true;
    $scope.showAlertMesage = false;
    $scope.successMessage = false;
    $scope.errorMessage = false;

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Dashboard Index";
    $rootScope.MasterConstant.ShortTitle = "Indices";

    $scope.HomeListItems = [];

    GetProjects();

    function GetProjects() {
        var data = {};
        apiService.get(appSettings.getMasterDashboardIndices, data).then(function (projectData) {
            $scope.HomeListItems = projectData.data;
        }, function () {
            alert('Error occured');
        });
    };

});