﻿
app.service('apiService', ['$http', '$q', '$timeout', 'appSettings', '$rootScope', '$filter', function ($http, $q, $timeout, appSettings, $rootScope, $filter) {

    var apiService = {};
    var apiBase = appSettings.apiBase;

    //===========================GET RESOURCE==============================
    var get = function (module, parameter) {

        var response = $http.get(
                apiBase + module,
               { params: parameter },
               { headers: { 'Content-Type': 'application/json', 'ApiKey': 'oflr74MtYqrgXGUfu/HvxOk9z/wgHAV9uSmP6fZqIJAxA1LWkybDZHm3V6qLk33M' } }
            );

        return response;
    };

    //===========================CREATE RESOURCE==============================
    var post = function (module, parameter) {
        //  console.log("hitting Service=============");

        var response = $http.post(
             apiBase + module,
             parameter,
             {
                 params: parameter,
                 headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'ApiKey': 'oflr74MtYqrgXGUfu/HvxOk9z/wgHAV9uSmP6fZqIJAxA1LWkybDZHm3V6qLk33M' }
                 //, contentType: "application/json; charset=utf-8"
             });

        return response;        
    };

    var post2 = function (module, data) {
        var response = $http({
            method: 'POST',
            url: apiBase + module,
            data: '' + JSON.stringify(data) + '',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            headers: {
                'Content-Type': 'application/json; charset=utf-8',
                'ApiKey': 'oflr74MtYqrgXGUfu/HvxOk9z/wgHAV9uSmP6fZqIJAxA1LWkybDZHm3V6qLk33M'
            }
        });

        return response;
    };

    //===========================CREATE BINARY DATA==============================
    var createBinary = function (module, parameter) {

        var response = $http.get(
                apiBase + module, {
                    params: parameter,
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    contentType: "application/json; charset=utf-8",
                    responseType: 'arraybuffer'
                });

        return response;
    };


    //===========================UPDATE RESOURCE==============================
    var update = function (module, parameter) {
        // console.log("hitting Service=============");

        var deferred = $q.defer();

        $http.post(
            apiBase + module + '/' + parameter.id, parameter,
            {
                headers: { 'Content-Type': 'application/json', 'ApiKey': 'oflr74MtYqrgXGUfu/HvxOk9z/wgHAV9uSmP6fZqIJAxA1LWkybDZHm3V6qLk33M' }
            }).success(function (response) {

            deferred.resolve(response);

        });

        return deferred.promise;
    };


    //===========================DELETE RESOURCE==============================
    var delet = function (module, parameter) {
        // console.log("hitting Service=============");

        var deferred = $q.defer();

        $http.post(apiBase + module + '/' + parameter.id, parameter,
            {
                headers: { 'Content-Type': 'application/json', 'ApiKey': 'oflr74MtYqrgXGUfu/HvxOk9z/wgHAV9uSmP6fZqIJAxA1LWkybDZHm3V6qLk33M' }
            }).success(function (response) {

            deferred.resolve(response);

        });

        return deferred.promise;
    };




    apiService.get = get;

    apiService.post = post;
    apiService.update = update;
    apiService.delet = delet;
    apiService.createBinary = createBinary;
    apiService.post2 = post2;

    return apiService;

}]);
