﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/angular.min.js" />
/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />

app.controller("HolidayController", function ($scope, $rootScope, $filter, apiService, appSettings) {

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Manage Holidays";
    $rootScope.MasterConstant.ShortTitle = "Holiday";

    var todayDateString = new Date().getFullYear() + "-" + (new Date().getMonth() + 1) + "-" + new Date().getDate();

    $scope.addItem = {
        HolidayID: 0,
        DateValue: todayDateString,
        Comments: "",
        LocationID: 0
    };

    $scope.selectedLocation = 0;

    $scope.years = [];
    for (var yy = 2018; yy <= 2025; yy++)
    {
        $scope.years.push(yy);
    }

    $scope.selectedYear = new Date().getFullYear();
    $scope.yearChanged = false;

    $scope.allHolidayItems = [];
    $scope.holidayItems = [];
    $scope.locationItems = [];

    $scope.showPane = "dashboard";

    $scope.addError = {
        Location: false,
        Date: false,
        Comments: false,
        errorOccured: false
    };

    
    GetHolidays();
    GetLocations();

    function GetHolidays() {
        var data = {};
        data.year = $scope.selectedYear;
        apiService.get(appSettings.getHolidays, data).then(function (holidayData) {
            $scope.allHolidayItems = holidayData.data;
            //On Screen Load
            if ($scope.holidayItems.length == 0) {
                GetLocationData(0); 
            }
            //If Year Changed
            if($scope.yearChanged)
            {
                GetLocationData($scope.selectedLocation);
                $scope.yearChanged = false;
            }
        }, function () {
            alert('Error occured while fetching Holiday Data.');
        });
    }

    function GetLocations() {
        var data = {};
        apiService.get(appSettings.getLocations, data).then(function (locationData) {
            $scope.locationItems = locationData.data;
            var allLocationItem = {
                LocationID: 0,
                LocationName: "National Holiday"
            };
            $scope.locationItems.splice(0,0,allLocationItem);
        }, function () {
            alert('Error occured while fetching Location Data.');
        });
    }

    $scope.loadLocationData = function () {
        if ($scope.selectedLocation != undefined) {
            GetLocationData($scope.selectedLocation);
        }
    }

    function GetLocationData(locationID) {
        $scope.holidayItems = $filter('filter')($scope.allHolidayItems, { LocationID: locationID });
        angular.forEach($scope.holidayItems, function (val) {
            //alert(val.DateValue);
            //val.DateValue = Date.parse(val.DateValue);
        });
    }

    $scope.onYearChange = function () {
        $scope.yearChanged = true;
        GetHolidays();
    }


    $scope.addHoliday = function () {
        var isValid = validate();
        if (isValid) {
            AddHoliday();
            clearHolidayItem();
            $scope.showPane = 'dashboard';
        }
    }

    function validate() {
        clearHolidayItem();
        if ($scope.addItem.LocationID < 0) {
            $scope.addError.Location = true;
            $scope.addError.errorOccured = true;
        }
        if ($scope.addItem.DateValue == "" || Date.parse($scope.addItem.DateValue) == null) {
            $scope.addError.Date = true;
            $scope.addError.errorOccured = true;
        }
        if ($scope.addItem.Comments == "") {
            $scope.addError.Comments = true;
            $scope.addError.errorOccured = true;
        }

        return !($scope.addError.errorOccured);
    }

    function AddHoliday() {
        var data = {};
        data.holiday = {
            HolidayID: 0,
            LocationID: $scope.addItem.LocationID,
            DateValue: $scope.addItem.DateValue,
            Comments: $scope.addItem.Comments
        };

        apiService.get(appSettings.addHoliday, data).then(function (holidayID) {
            var datt = new Date($scope.addItem.DateValue);
            var dateStringg = (datt.getMonth() + 1) + "/" + datt.getDate() + "/" + datt.getFullYear();
            var pushItem = {
                HolidayID: holidayID.data,
                DateValue: data.holiday.DateValue,
                LocationID: data.holiday.LocationID,
                Comments: data.holiday.Comments,
                DateString: dateStringg
            };
            $scope.holidayItems.push(pushItem);
        }, function () {
            alert('Error occured while adding Holiday.');
        });
    }

    $scope.deleteHoliday = function (holidayId) {
        var data = {};
        data.holidayID = holidayId;
        apiService.get(appSettings.deleteHoliday, data).then(function (holidayIdData) {
            if (holidayIdData == true || holidayIdData.data == true) {
                var selectedRow = $filter('filter')($scope.holidayItems, { HolidayID: holidayId });
                $scope.holidayItems.splice($scope.holidayItems.indexOf(selectedRow), 1)
            }
        }, function () {
            alert('Error occured while deleting Holiday.');
        });
    }

    $scope.editHoliday = function (holiday) {
        holiday.isEditMode = true;
    }

    $scope.updateHoliday = function (holiday) {
        $scope.addItem = {
            HolidayID: 0,
            DateValue: $scope.addItem.DateValue,
            LocationID: $scope.addItem.LocationID,
            Comments: $scope.addItem.Comments
        };
        var isValid = validate();
        if (isValid) {
            EditHoliday();
            clearHolidayItem();
            holiday.isEditMode = false;
        }
    }

    $scope.cancelEdit = function (location) {
        location.isEditMode = false;
    };

    function EditHoliday() {
        var data = {};
        var newItem = {
            HolidayID: 0,
            DateValue: $scope.addItem.DateValue,
            LocationID: $scope.addItem.LocationID,
            Comments : $scope.addItem.Comments
        }
        data.holiday = newItem;

        apiService.get(appSettings.updateHoliday, data).then(function (response) {
            var datt = new Date($scope.addItem.DateValue);
            var dateStringg = (datt.getMonth() + 1) + "/" + datt.getDate() + "/" + datt.getFullYear();
            var selectedRow = $filter('filter')($scope.holidayItems, { DateValue: newItem.DateValue })[0];
            selectedRow.DateValue = newItem.DateValue;
            selectedRow.DateString = dateStringg;
            selectedRow.LocationID = newItem.LocationID;
            selectedRow.Comments = newItem.Comments;
        }, function () {
            alert('Error occured while Updating Holiday.');
        });
    }


    $scope.cancelAdd = function () {
        clearHolidayItem();
        $scope.showPane = "dashboard";
    };

    function clearHolidayItem() {
        $scope.addError = {
            Location: false,
            Date: false,
            Comments: false,
            errorOccured: false
        };
    }
});