﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/angular.min.js" />
/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />

app.controller("PMPController", function ($scope, $rootScope, $filter, apiService, appSettings) {

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Project Management Portal";
    $rootScope.MasterConstant.ShortTitle = "PMP";

    $scope.addItem = {
        ProjectID: 0,
        ProjectName: "",
        Area: {
            AreaID: 0,
            AreaName: "--Select--"
        }
    };

    $scope.projectItems = [];
    $scope.areaItems = [];


    $scope.showPane = "dashboard";

    $scope.addAreaItem = {
        AreaID: 0,
        AreaName: ""
    };

    $scope.addError = {
        ProjectName: false,
        AreaID: false,
        AreaName: false,
        errorOccured: false
    };

    GetAreas();
    GetProjects();

    function GetAreas() {
        var data = {};
        apiService.get(appSettings.getAreas, data).then(function (areaData) {
            $scope.areaItems = areaData.data;
            $scope.areaItems.splice(0, 0, { AreaID: 0, AreaName: "--Select--" });
        }, function () {
            alert('Error occured while fetching Areas.');
        });
    }

    function GetProjects() {
        var data = {};
        apiService.get(appSettings.getProjects, data).then(function (projectData) {
            $scope.projectItems = projectData.data;
        }, function () {
            alert('Error occured while fetching Projects.');
        });
    }

    $scope.addProject = function () {
        $scope.resetAddError();
        if ($scope.addItem.ProjectName == "") {
            $scope.addError.ProjectName = true;
            $scope.addError.errorOccured = true;
        }
        if ($scope.addItem.AreaID == $scope.areaItems[0].AreaID) {
            $scope.addError.AreaID = true;
            $scope.addError.errorOccured = true;
        }
        if (!$scope.addError.errorOccured) {
            //$scope._projectService.addProject($scope.addItem);
            AddProject();
            $scope.resetAddItem();
        }
    }

    function AddProject() {
        var data = {};
        var newItem = {
            ProjectName: $scope.addItem.ProjectName,
            AreaID: $scope.addItem.Area.AreaID
        }
        data.project = newItem;

        apiService.get(appSettings.addProject, data).then(function (projectIDData) {
            //var selectedRow = $filter('filter')($scope.projectItems, { ProjectName: newItem.ProjectName })[0];
            //selectedRow.ProjectID = projectIDData.data;
            var pushItem = {
                ProjectID: projectIDData.data,
                ProjectName: newItem.ProjectName,
                Area: {
                    AreaID: $scope.addItem.Area.AreaID,
                    AreaName: $filter('filter')($scope.areaItems, { AreaID: newItem.AreaID })[0].AreaName
                }
            };
            $scope.projectItems.push(newItem);
        }, function () {
            alert('Error occured while adding Project.');
        });
    }

    $scope.deleteProject = function (projectId)
    {
        var data = {};
        data.projectID = projectId;
        apiService.get(appSettings.deleteProject, data).then(function (projectIDData) {
            if (projectIDData == true || projectIDData.data == true)
            {
                var selectedRow = $filter('filter')($scope.projectItems, { ProjectID: projectId });
                $scope.projectItems.splice($scope.projectItems.indexOf(selectedRow), 1)
            }
        }, function () {
            alert('Error occured while deleting Project.');
        });
    }

    $scope.editProject = function (projectItem) {
        $scope.addItem = {
            ProjectID: projectItem.ProjectID,
            ProjectName: projectItem.ProjectName,
            Area: {
                AreaID: projectItem.AreaID,
                AreaName: projectItem.AreaName
            }
        };
        $scope.showPane = 'editProject';
    }

    $scope.updateProject = function () {
        $scope.resetAddError();
        if ($scope.addItem.ProjectName == "") {
            $scope.addError.ProjectName = true;
            $scope.addError.errorOccured = true;
        }
        if ($scope.addItem.Area.AreaID == $scope.areaItems[0].AreaID) {
            $scope.addError.AreaID = true;
            $scope.addError.errorOccured = true;
        }
        if (!$scope.addError.errorOccured) {
            EditProject();
            $scope.resetAddItem();
        }
    }

    function EditProject() {
        var data = {};
        var newItem = {
            ProjectID : $scope.addItem.ProjectID,
            ProjectName: $scope.addItem.ProjectName,
            AreaID: $scope.addItem.Area.AreaID
        }
        data.project = newItem;

        apiService.get(appSettings.updateProject, data).then(function (projectIDData) {
            var selectedRow = $filter('filter')($scope.projectItems, { ProjectName: newItem.ProjectName })[0];
            selectedRow.ProjectName = newItem.ProjectName;
            selectedRow.AreaID = newItem.AreaID;
            selectedRow.AreaName = $filter('filter')($scope.areaItems, { AreaID: newItem.AreaID })[0].AreaName;
        }, function () {
            alert('Error occured while adding Project.');
        });
    }

    $scope.resetAddError = function () {
        $scope.addError = {
            ProjectName: false,
            AreaID: false,
            AreaName: false,
            errorOccured: false
        };
    }

    $scope.resetAddItem = function () {
        clearProjectItem();
    }


    $scope.resetEditItem = function () {
        clearProjectItem();
    }

    function clearProjectItem() {
        $scope.addItem = {
            ProjectID: 0,
            ProjectName: "",
            Area: {
                AreaID: 0,
                AreaName: "--Select--"
            }
        };
        $scope.resetAddArea();
        $scope.showPane = "dashboard";
    }



    $scope.addArea = function () {
        AddArea();
    }

    function AddArea() {
        var newItem = {
            AreaID: $scope.areaItems.length,
            AreaName: $scope.addAreaItem.AreaName
        };

        var data = {};
        data.area = $scope.addAreaItem;
        apiService.get(appSettings.addArea, data).then(function (areaIdData) {
            newItem.AreaID = areaIdData.data;
            $scope.areaItems.push(newItem);
            $scope.resetAddArea();
        }, function () {
            $scope.resetAddArea();
            alert('Error occured while fetching Areas.');
        });
    }

    $scope.resetAddArea = function () {
        $scope.addAreaItem = {
            AreaID: 0,
            AreaName: ""
        };
        $scope.showPane = "dashboard";
    }
});