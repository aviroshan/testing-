﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />

app.controller("PMPHomeController", function ($scope, $rootScope, appSettings, apiService, $filter) {
    /*-----------------Alert Modal Variables and Data loading---------------------------*/
    $scope.data_waiting = true;
    $scope.showAlertMesage = false;
    $scope.successMessage = false;
    $scope.errorMessage = false;

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Project Management Portal";
    $rootScope.MasterConstant.ShortTitle = "PMP Home";

    $scope.SubItems = [];

    GetSubItems();

    function GetSubItems() {
        var data = {};
        apiService.get(appSettings.getPMPSubItems, data).then(function (projectData) {
            $scope.SubItems = projectData.data;
        }, function () {
            alert('Error occured');
        });
    };

});