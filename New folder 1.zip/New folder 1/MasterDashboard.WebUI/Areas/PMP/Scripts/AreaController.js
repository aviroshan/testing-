﻿app.controller("AreaController", function ($scope, $rootScope, $filter, apiService, appSettings) {

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Manage Area";
    $rootScope.MasterConstant.ShortTitle = "Area";

    $scope.addItem = {
        AreaId: 0,
        AreaName: "",
        User: {
            UserId: 0,
            UserName: "--Select--"
        }

    };

    $scope.areaItems = [];
    $scope.userItems = [];


    $scope.showPane = "dashboard";
    $scope.innerPane = "dashboard";

    $scope.selectedUser = [];

    $scope.addError = {
        AreaName: false,
        AreaId: false,
        UserId: false,
        UserName: false
    };


    GetAreas();
    GetUsers();

    function GetAreas() {
        var data = {};
        apiService.get(appSettings.getAreas, data).then(function (areaData) {
            $scope.areaItems = areaData.data;
        }, function () {
            alert('Error occured while fetching Areas.');
        });

    }

    function GetUsers() {
        var data = {};
        apiService.get(appSettings.getTeamMembers, data).then(function (userData) {
            $scope.userItems = userData.data;
        }, function () {
            alert('Error occured while fetching Users.');
        });
    }

    $scope.addArea = function () {
        $scope.resetAddError();
        if ($scope.addItem.AreaName == "") {
            $scope.addError.AreaName = true;
            $scope.addError.errorOccured = true;
        }
        if ($scope.addItem.User.UserId == $scope.userItems[0].UserId) {
            $scope.addError.UserId = true;
            $scope.addError.errorOccured = true;
        }

        if (!$scope.addError.errorOccured) {
            //$scope._projectService.addProject($scope.addItem);
            AddArea();
            $scope.resetAddItem();
        }
    }

    function AddArea() {
        var data = {};
        var newItem = {
            AreaId: 0,
            AreaName: $scope.addItem.AreaName,
            User: $scope.addItem.User.UserId,
        }
        data.area = newItem;

        apiService.get(appSettings.addArea, data).then(function (areaIdData) {
            var pushItem = {
                AreaId: areaIdData.data,
                AreaName: newItem.AreaName,

            };

            $scope.areaItems.push(pushItem);
        }, function () {
            alert('Error occured while adding Area.');
        });
    }

   

    $scope.addAreaMember = function (areaItem) {
        $scope.addItem = {
            AreaId: areaItem.AreaId,
            AreatName: areaItem.AreaName,
            //User: {
            //    UserId: projectItem.UserId,
            //    UserName: projectItem.UserName
            //}
        };
        $scope.showPane = 'addAreaMember';
    }

    $scope.resetAddItem = function () {
        clearAreaItem();
    }

    function clearAreaItem() {
        $scope.addItem = {
            AreaId: 0,
            AreaName: ""
            
        };
       // $scope.resetAddProgram();
       $scope.showPane = "dashboard";
    }
    $scope.resetAddError = function () {
        $scope.addError = {
            AreaName: false,
            AreaId: false,
            errorOccured: false
        };
    }

    $scope.resetAddItem = function () {
        clearAreaItem();
    }
    function clearAreaItem() {
        $scope.addItem = {
            AreaId: 0,
            AreaName: ""
          
        };
//$scope.resetAddProgram();
$scope.showPane = "dashboard";
    }

    $scope.updateArea = function () {
        $scope.resetAddError();
        if ($scope.addItem.AreaName == "") {
            $scope.addError.AreatName = true;
            $scope.addError.errorOccured = true;
        }

        if (!$scope.addError.errorOccured) {
            EditArea();
            $scope.resetAddItem();
        }
    }

    function EditArea() {
        var data = {};
        var newItem = {
            AreaId: $scope.addItem.AreaId,
            AreaName: $scope.addItem.AreaName

        }
        data.area = newItem;

        apiService.get(appSettings.updateArea, data).then(function (areaIdData) {
            var selectedRow = $filter('filter')($scope.areaItems, { AreaName: newItem.AreaName })[0];
            selectedRow.AreaName = newItem.AreaName;
            selectedRow.AreaId = newItem.AreaId;
           
        }, function () {
            alert('Error occured while adding Area.');
        });
    }

    $scope.editArea = function (areaItem) {
        console.log(areaItem.AreaId);
        $scope.editableArea.AreaId = areaItem.AreaId;
        $scope.editableArea.AreaName = areaItem.AreaName;
        // Get Temammbers for area by pasing AreaID
        $scope.editableArea.TeamMembers = [
            {
                AreaId: areaItem.AreaId, Name: 'Avinash', UserId : 1
            },
            {
                AreaId: areaItem.AreaId, Name: 'Salim', UserId: 2
            },
            {
                AreaId: areaItem.AreaId, Name: 'Karthik', UserId: 3
            }
        ]; //
    };

    $scope.editableArea = {
        AreaId : 0,
        AreaName: '',
        TeamMembers : []
    };

    $scope.addTeamMember = function () {
        var user = $scope.selectedUser;
        //var anc = { AreaId: 1, Name: $scope.newTeamMember, UserId: 5 };
        //$scope.editableArea.TeamMembers.push(anc);
        //$scope.newTeamMember = '';
    };

});