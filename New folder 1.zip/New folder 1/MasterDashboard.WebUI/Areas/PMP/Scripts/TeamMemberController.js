﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/angular.min.js" />
/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />

app.controller("TeamMemberController", function ($scope, $rootScope, $filter, apiService, appSettings) {

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Manage TeamMembers";
    $rootScope.MasterConstant.ShortTitle = "Team Member";

    $scope.addItem = {
        UserId: "",
        Name: "",
        CognizantId: 0,
        EmailID: "",
        Password: "",
        LocationId : 0
    };

    $scope.teamMemberItems = [];

    $scope.showPane = "dashboard";

    $scope.addError = {
        UserId: false,
        CognizantId: false,
        Name: false,
        EmailID: false,
        Password: false,
        LocationId :false
    };

    GetTeamMembers();

    function GetTeamMembers() {
        var data = {};
        apiService.get(appSettings.getTeamMembers, data).then(function (teamMemberData) {
            $scope.teamMemberItems = teamMemberData.data;
        }, function () {
            alert('Error occured while fetching TeamMember Data.');
        });
    }

    $scope.locationItems = [];
    GetLocations();

    function GetLocations() {
        var data = {};
        apiService.get(appSettings.getLocations, data).then(function (locationData) {
            $scope.locationItems = locationData.data;
        }, function () {
            alert('Error occured while fetching Location Data.');
        });
    }

    function validate()
    {
        $scope.resetAddError();
        var isValid = true;
        if ($scope.addItem.UserId == "") {
            $scope.addError.UserId = true;
            isValid = false;
        }
        if ($scope.addItem.Name == "") {
            $scope.addError.Name = true;
            isValid = false;
        }
        if (parseInt($scope.addItem.CognizantId) == null) {
            $scope.addError.CognizantId = true;
            isValid = false;
        }

        if (parseInt($scope.addItem.LocationId) == null) {
            $scope.addError.LocationId = true;
            isValid = false;
        }
        return isValid;
    }

    $scope.addTeamMember = function () {
        var isValid = validate();
        if (isValid) {
            AddTeamMember();
            clearTeamMemberItem();
        }
    }

    function AddTeamMember() {
        var data = {};
        data.teamMember = {
            UserId: $scope.addItem.UserId,
            Name: $scope.addItem.Name,
            LocationId: $scope.addItem.LocationId,
            CognizantId: $scope.addItem.CognizantId,
            Password: $scope.addItem.Password,
            EmailID: $scope.addItem.EmailID
        };

        apiService.get(appSettings.addTeamMember, data).then(function (teamMemberID) {
            if (teamMemberID.data == true) {
                var pushItem = {
                    UserId: data.UserId,
                    Name: data.teamMember.Name,
                    LocationId: data.LocationId,
                    CognizantId: data.CognizantId,
                    Password: data.Password,
                    EmailID: data.EmailID
                };
                $scope.teamMemberItems.push(pushItem);
                $scope.resetAddError();
            }
            else
            {
                alert('Error occured while adding TeamMember.');
            }
        }, function () {
            alert('Error occured while adding TeamMember.');
        });
    }

    $scope.deleteNotAllowed = function () {
        alert('Cannot be deleted as Holiday Mapping found.'); t
    };

    $scope.deleteTeamMember = function (userId) {
        var data = {};
        data.teamMemberID = userId;
        apiService.get(appSettings.deleteTeamMember, data).then(function (teamMemberIdData) {
            if (teamMemberIdData == true || teamMemberIdData.data == true) {
                var selectedRow = $filter('filter')($scope.teamMemberItems, { UserId: userId });
                $scope.teamMemberItems.splice($scope.teamMemberItems.indexOf(selectedRow), 1);
            }
        }, function () {
            alert('Error occured while deleting TeamMember.');
        });
    }

    $scope.editTeamMember = function (teamMember) {
        teamMember.isEditMode = true;
    };

    $scope.updateTeamMember = function (teamMember) {
        $scope.addItem = {
            UserId: teamMember.UserId,
            Name: teamMember.Name,
            LocationId: teamMember.LocationId,
            CognizantId: teamMember.CognizantId,
            Password: teamMember.Password,
            EmailID: teamMember.EmailID
        };

        var isValid = validate();
        if (isValid) {
            EditTeamMember();
            clearTeamMemberItem();
            teamMember.isEditMode = false;
            $scope.resetAddError();
        }
        else
        {
            alert('Validation error exists');
        }
    }

    function EditTeamMember() {
        var data = {};
        data.teamMember = {
            UserId: $scope.addItem.UserId,
            Name: $scope.addItem.Name,
            LocationId: $scope.addItem.LocationId,
            CognizantId: $scope.addItem.CognizantId,
            Password: $scope.addItem.Password,
            EmailID: $scope.addItem.EmailID
        };

        apiService.get(appSettings.updateTeamMember, data).then(function (response) {
            var selectedRow = $filter('filter')($scope.teamMemberItems, { Name: newItem.Name })[0];
            selectedRow.Name = newItem.Name;
        }, function () {
            alert('Error occured while Updating TeamMember.');
        });
    }

    $scope.resetAddError = function () {
        $scope.addError = {
            UserId: false,
            CognizantId: false,
            Name: false,
            EmailID: false,
            Password: false,
            LocationId: false
        };
    }

    $scope.cancelAdd = function () {
        clearTeamMemberItem();
    };

    $scope.cancelEdit = function (teamMember) {
        teamMember.isEditMode = false;
    };

    function clearTeamMemberItem() {
        $scope.addItem = {
            UserId: "",
            Name: "",
            CognizantId: 0,
            EmailID: "",
            Password: "",
            LocationId: 0
        };
        $scope.showPane = "dashboard";
    }
});