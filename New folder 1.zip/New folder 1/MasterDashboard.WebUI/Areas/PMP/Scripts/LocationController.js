﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/angular.min.js" />
/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />

app.controller("LocationController", function ($scope, $rootScope, $filter, apiService, appSettings) {

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Manage Locations";
    $rootScope.MasterConstant.ShortTitle = "Location";

    $scope.addItem = {
        LocationID: 0,
        LocationName: ""
    };

    $scope.locationItems = [];

    $scope.showPane = "dashboard";

    $scope.addError = false;

    GetLocations();

    function GetLocations() {
        var data = {};
        apiService.get(appSettings.getLocations, data).then(function (locationData) {
            $scope.locationItems = locationData.data;
        }, function () {
            alert('Error occured while fetching Location Data.');
        });
    }

    $scope.addLocation = function () {
        $scope.resetAddError();
        if ($scope.addItem.LocationName == "") {
            $scope.addError = true;
        }

        if (!$scope.addError) {
            AddLocation();
            clearLocationItem();
        }
    }

    function AddLocation() {
        var data = {};
        data.location = {
            LocationID: 0,
            LocationName: $scope.addItem.LocationName
        };

        apiService.get(appSettings.addLocation, data).then(function (locationID) {
            var pushItem = {
                LocationID: locationID.data,
                LocationName: data.location.LocationName
            };
            $scope.locationItems.push(pushItem);
        }, function () {
            alert('Error occured while adding Location.');
        });
    }

    $scope.deleteNotAllowed = function () {
        alert('Cannot be deleted as Holiday Mapping found.');t
    };

    $scope.deleteLocation = function (locationId) {
        var data = {};
        data.locationID = locationId;
        apiService.get(appSettings.deleteLocation, data).then(function (locationIdData) {
            if (locationIdData == true || locationIdData.data == true) {
                var selectedRow = $filter('filter')($scope.locationItems, { LocationID: locationId });
                $scope.locationItems.splice($scope.locationItems.indexOf(selectedRow), 1);
            }
        }, function () {
            alert('Error occured while deleting Location.');
        });
    }

    $scope.editLocation = function (location) {
        location.isEditMode = true;
    };

    $scope.updateLocation = function (location) {
        $scope.resetAddError();
        $scope.addItem = {
            LocationID: location.LocationID,
            LocationName: location.LocationName
        };
        if ($scope.addItem.LocationName == "") {
            $scope.addError = true;
        }
        if (!$scope.addError) {
            EditLocation();
            clearLocationItem();
            location.isEditMode = false;
        }
    }

    function EditLocation() {
        var data = {};
        var newItem = {
            LocationID: $scope.addItem.LocationID,
            LocationName: $scope.addItem.LocationName
        }
        data.location = newItem;

        apiService.get(appSettings.updateLocation, data).then(function (response) {
            var selectedRow = $filter('filter')($scope.locationItems, { LocationName: newItem.LocationName })[0];
            selectedRow.LocationName = newItem.LocationName;
        }, function () {
            alert('Error occured while Updating Location.');
        });
    }

    $scope.resetAddError = function () {
        $scope.addError = false;
    }

    $scope.cancelAdd = function () {
        clearLocationItem();
    };

    $scope.cancelEdit = function (location) {
        location.isEditMode = false;
    };

    function clearLocationItem() {
        $scope.addItem = {
            LocationID: 0,
            LocationName: ""
        };
        $scope.showPane = "dashboard";
    }
});