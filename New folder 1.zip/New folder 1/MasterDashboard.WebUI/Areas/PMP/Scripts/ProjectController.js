﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/angular.min.js" />
/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />

app.controller("ProjectController", function ($scope, $rootScope, $filter, apiService, appSettings) {

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Manage Projects";
    $rootScope.MasterConstant.ShortTitle = "Projects";

    $scope.addItem = {
        ProjectID: 0,
        ProjectName: "",
        Program: {
            ProgramID: 0,
            ProgramName: "--Select--"
        },
        Domain: {
            DomainID: 0,
            DomainName: "--Select--"
        }
    };

    $scope.projectItems = [];
    $scope.programItems = [];


    $scope.showPane = "dashboard";
    $scope.innerPane = "dashboard";

    $scope.addProgramItem = {
        ProgramID: 0,
        ProgramName: "",
        Domain: {
            DomainID: 0,
            DomainName: ""
        }
    };

    $scope.addError = {
        ProjectName: false,
        ProgramID: false,
        ProgramName: false,
        DomainID: false,
        errorOccured: false
    };

    GetDomains();
    GetPrograms();
    GetProjects();

    function GetDomains() {
        var data = {};
        apiService.get(appSettings.getDomains, data).then(function (domainData) {
            $scope.domainItems = domainData.data;
            $scope.domainItems.splice(0, 0, { DomainID: 0, DomainName: "--Select--" });
        }, function () {
            alert('Error occured while fetching Domains.');
        });
    }

    function GetPrograms() {
        var data = {};
        apiService.get(appSettings.getPrograms, data).then(function (programData) {
            $scope.programItems = programData.data;
            $scope.programItems.splice(0, 0, { ProgramID: 0, ProgramName: "--Select--" });
        }, function () {
            alert('Error occured while fetching Programs.');
        });
    }

    function GetProjects() {
        var data = {};
        apiService.get(appSettings.getProjects, data).then(function (projectData) {
            $scope.projectItems = projectData.data;
        }, function () {
            alert('Error occured while fetching Projects.');
        });
    }

    $scope.addProject = function () {
        $scope.resetAddError();
        if ($scope.addItem.ProjectName == "") {
            $scope.addError.ProjectName = true;
            $scope.addError.errorOccured = true;
        }
        if ($scope.addItem.Program.ProgramID == $scope.programItems[0].ProgramID) {
            $scope.addError.ProgramID = true;
            $scope.addError.errorOccured = true;
        }
        //if ($scope.addItem.Domain.DomainID == $scope.programItems[0].DomainID) {
        //    $scope.addError.DomainID = true;
        //    $scope.addError.errorOccured = true;
        //}
        if (!$scope.addError.errorOccured) {
            //$scope._projectService.addProject($scope.addItem);
            AddProject();
            $scope.resetAddItem();
        }
    }

    function AddProject() {
        var data = {};
        var newItem = {
            ProjectID: 0,
            ProjectName: $scope.addItem.ProjectName,
            ProgramID: $scope.addItem.Program.ProgramID,
            //DomainID: $scope.addItem.Domain.DomainID
        }
        data.project = newItem;

        apiService.get(appSettings.addProject, data).then(function (projectIDData) {
            //var selectedRow = $filter('filter')($scope.projectItems, { ProjectName: newItem.ProjectName })[0];
            //selectedRow.ProjectID = projectIDData.data;
            var pushItem = {
                ProjectID: projectIDData.data,
                ProjectName: newItem.ProjectName,
                ProgramID: newItem.ProgramID,
                ProgramName: $filter('filter')($scope.programItems, { ProgramID: newItem.ProgramID })[0].ProgramName,
                DomainID: 0,
                DomainName: ''
            };
            pushItem.DomainID = $filter('filter')($scope.programItems, { ProgramID: pushItem.ProgramID })[0].DomainID;
            pushItem.DomainName = $filter('filter')($scope.domainItems, { DomainID: pushItem.DomainID })[0].DomainName;
            $scope.projectItems.push(pushItem);
        }, function () {
            alert('Error occured while adding Project.');
        });
    }

    $scope.deleteProject = function (projectId) {
        var data = {};
        data.projectID = projectId;
        apiService.get(appSettings.deleteProject, data).then(function (projectIDData) {
            if (projectIDData == true || projectIDData.data == true) {
                var selectedRow = $filter('filter')($scope.projectItems, { ProjectID: projectId });
                $scope.projectItems.splice($scope.projectItems.indexOf(selectedRow), 1)
            }
        }, function () {
            alert('Error occured while deleting Project.');
        });
    }

    $scope.editProject = function (projectItem) {
        $scope.addItem = {
            ProjectID: projectItem.ProjectID,
            ProjectName: projectItem.ProjectName,
            //Program: {
            //    ProgramID: projectItem.ProgramID,
            //    ProgramName: projectItem.ProgramName
            //},
            Domain: {
                DomainID: projectItem.DomainID,
                DomainName: projectItem.DomainName
            }
        };
        $scope.showPane = 'editProject';
    }

    $scope.updateProject = function () {
        $scope.resetAddError();
        if ($scope.addItem.ProjectName == "") {
            $scope.addError.ProjectName = true;
            $scope.addError.errorOccured = true;
        }
        if ($scope.addItem.Program.ProgramID == $scope.programItems[0].ProgramID) {
            $scope.addError.ProgramID = true;
            $scope.addError.errorOccured = true;
        }
        if ($scope.addItem.Domain.DomainID == $scope.domainItems[0].DomainID) {
            $scope.addError.DomainID = true;
            $scope.addError.errorOccured = true;
        }
        if (!$scope.addError.errorOccured) {
            EditProject();
            $scope.resetAddItem();
        }
    }

    function EditProject() {
        var data = {};
        var newItem = {
            ProjectID: $scope.addItem.ProjectID,
            ProjectName: $scope.addItem.ProjectName,
            ProgramID: $scope.addItem.Program.ProgramID,
            DomainID: $scope.addItem.Domain.DomainID
        }
        data.project = newItem;

        apiService.get(appSettings.updateProject, data).then(function (projectIDData) {
            var selectedRow = $filter('filter')($scope.projectItems, { ProjectName: newItem.ProjectName })[0];
            selectedRow.ProjectName = newItem.ProjectName;
            selectedRow.ProgramID = newItem.ProgramID;
            selectedRow.ProgramName = $filter('filter')($scope.programItems, { ProgramID: newItem.ProgramID })[0].ProgramName;
        }, function () {
            alert('Error occured while adding Project.');
        });
    }

    $scope.resetAddError = function () {
        $scope.addError = {
            ProjectName: false,
            ProgramID: false,
            ProgramName: false,
            errorOccured: false
        };
    }

    $scope.resetAddItem = function () {
        clearProjectItem();
    }


    $scope.resetEditItem = function () {
        clearProjectItem();
    }

    function clearProjectItem() {
        $scope.addItem = {
            ProjectID: 0,
            ProjectName: "",
            Program: {
                ProgramID: 0,
                ProgramName: "--Select--"
            },
            Domain: {
                DomainID: 0,
                DomainName: "--Select--"
            }
        };
        $scope.resetAddProgram();
        $scope.showPane = "dashboard";
    }



    $scope.addProgram = function () {
        AddProgram();
    }

    function AddProgram() {
        var newItem = {
            ProgramID: 0,
            ProgramName: $scope.addProgramItem.ProgramName,
            DomainID: $scope.addProgramItem.Domain.DomainID
        };
        var pushItem = {
            ProgramID: 0,
            ProgramName: $scope.addProgramItem.ProgramName,
            Domain: $scope.addProgramItem.Domain
        };

        var data = {};
        data.program = newItem;
        apiService.get(appSettings.addProgram, data).then(function (ProgramIDData) {
            pushItem.ProgramID = ProgramIDData.data;
            $scope.programItems.push(pushItem);
            $scope.resetAddProgram();
        }, function () {
            $scope.resetAddProgram();
            alert('Error occured while adding Project Programs.');
        });
    }

    $scope.resetAddProgram = function () {
        $scope.addProgramItem = {
            ProgramID: 0,
            ProgramName: "",
            Domain: {
                DomainID: 0,
                DomainName: ""
            }
        };
        $scope.showPane = "dashboard";
    }
});