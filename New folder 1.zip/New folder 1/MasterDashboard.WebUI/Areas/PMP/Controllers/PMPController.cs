﻿using MasterDashboard.BC;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MasterDashboard.WebUI.Areas.PMP.Controllers
{
    public class PMPController : Controller
    {
        // GET: PMP/PMP
        #region Views
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ProjectArea()
        {
            return View();
        }

        public ActionResult Location()
        {
            return View();
        }

        public ActionResult Holiday()
        {
            return View();
        }

        public ActionResult TeamMember()
        {
            return View();
        }
        public ActionResult Area()
        {
            return View();
        }

        //Done in MVC
        public ActionResult ProjectAllocation()
        {
            var projectAllocations = new ProjectAllocationBC().GetAllProjectAllocation();
            return View(projectAllocations);
        }
        #endregion 

        public JsonResult GetPMPSubItems()
        {
            var subItems = new[]{
             new{ Name = "Projects", Description = "Manage Projects", Click = Url.Action("ProjectArea", "PMP", new { area = "PMP" }).ToString()},
             new{ Name = "Location", Description = "For managing Work Locations of Team Members", Click = Url.Action("Location", "PMP", new { area = "PMP" }).ToString()},
             new{ Name = "Holidays", Description = "For managing Cognizant Holidays", Click = Url.Action("Holiday", "PMP", new { area = "PMP" }).ToString()},
             new{ Name = "Team Members Profile", Description = "Manage Projects & Project Areas", Click = Url.Action("TeamMember", "PMP", new { area = "PMP" }).ToString()},
             new{ Name = "Project Allocation", Description = "Manage Projects & Project Areas", Click = Url.Action("ProjectAllocation", "PMP", new { area = "PMP" }).ToString()},
             new{ Name = "Area", Description = "Manage Areas and its members", Click = Url.Action("Area", "PMP", new { area = "PMP" }).ToString()}
            };
            return Json(subItems, JsonRequestBehavior.AllowGet);
        }

        #region Project 
        public JsonResult GetProjects()
        {
            var projectItems = new ProjectBC().GetProjects();
            return Json(projectItems, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetProjectPrograms()
        {
            //var areaItems = new[]{
            // new{ AreaID = 1, AreaName = "GamePlan"},
            // new{ AreaID = 2, AreaName = "Pathway"},
            // new{ AreaID = 3, AreaName = "Mobius"},
            // new{ AreaID = 4, AreaName = "Others"},
            //};
            var areaItems = new ProjectBC().GetProjectPrograms();
            return Json(areaItems, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetProjectDomains()
        {
            var domainItems = new ProjectBC().GetProjectDomains();
            return Json(domainItems, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AddProject(string project)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Project>(project);
            var result = new ProjectBC().AddProject(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AddProgram(string program)
        {
            var newItem = JsonConvert.DeserializeObject<Model.ProjectProgram>(program);
            var result = new ProjectBC().AddProgram(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateProject(string project)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Project>(project);
            var result = new ProjectBC().UpdateProject(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteProject(int projectID)
        {
            var result = new ProjectBC().DeleteProject(projectID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Area

        public JsonResult GetAreas()
        {
            var areaItems = new AreaBC().GetAreas();
            return Json(areaItems, JsonRequestBehavior.AllowGet);
        }
        public JsonResult AddArea(string area)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Area>(area);
            var result = new AreaBC().AddArea(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        public JsonResult UpdateArea(string area)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Area>(area);
            var result = new AreaBC().UpdateArea(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }


        #endregion

        #region Location
        public JsonResult GetLocations()
        {
            var locations = new LocationBC().GetLocations();
            return Json(locations, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AddLocation(string location)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Location>(location);
            var result = new LocationBC().AddLocation(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateLocation(string location)
        {

            var newItem = JsonConvert.DeserializeObject<Model.Location>(location);
            var result = new LocationBC().UpdateLocation(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteLocation(int locationID)
        {
            var result = new LocationBC().DeleteLocation(locationID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Holiday
        public JsonResult GetHolidays(int year)
        {
            var holidays = new HolidayBC().GetAllHolidays(year);
            return Json(holidays, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AddHoliday(string holiday)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Holiday>(holiday);
            var result = new HolidayBC().AddHoliday(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateHoliday(string holiday)
        {

            var newItem = JsonConvert.DeserializeObject<Model.Holiday>(holiday);
            var result = new HolidayBC().UpdateHoliday(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteHoliday(int holidayID)
        {
            var result = new HolidayBC().DeleteHoliday(holidayID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region TeamMembers
        public JsonResult GetTeamMembers()
        {
            var teamMembers = new UserBC().GetUsers();
            return Json(teamMembers, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AddTeamMember(string teamMember)
        {
            var newItem = JsonConvert.DeserializeObject<Model.User>(teamMember);
            var result = new UserBC().AddUser(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateTeamMember(string teamMember)
        {

            var newItem = JsonConvert.DeserializeObject<Model.User>(teamMember);
            var result = new UserBC().UpdateUser(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteTeamMember(string teamMemberID)
        {
            var result = new UserBC().DeleteUser(teamMemberID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region ProjectAllocation
        public ActionResult CreateAllocation()
        {
            Model.ProjectAllocation allocation = new Model.ProjectAllocation();
            ViewBag.AllocationTypes = new SelectList(new ProjectAllocationTypeBC().GetAllProjectAllocationTypes(), "AllocationTypeID", "AllocationTypeName", 1);
            ViewBag.Projects = new SelectList(new ProjectBC().GetProjects(), "ProjectID", "ProjectName", 1);
            ViewBag.Users = new SelectList(new UserBC().GetUsers(), "UserID", "Name", 1);
            return View(allocation);
        }

        [HttpPost]
        public ActionResult CreateAllocation(Model.ProjectAllocation allocation)
        {
            new ProjectAllocationBC().AddProjectAllocation(allocation);
            return RedirectToAction("ProjectAllocation");
        }

        public ActionResult EditAllocation(int id)
        {
            Model.ProjectAllocation allocation = new ProjectAllocationBC().GetProjectAllocationByID(id);
            ViewBag.AllocationTypes = new SelectList(new ProjectAllocationTypeBC().GetAllProjectAllocationTypes(), "AllocationTypeID", "AllocationTypeName", allocation.AllocationTypeID.ToString());
            ViewBag.Projects = new SelectList(new ProjectBC().GetProjects(), "ProjectID", "ProjectName", allocation.ProjectID.ToString());
            ViewBag.Users = new SelectList(new UserBC().GetUsers(), "UserID", "Name", 1);
            return View(allocation);
        }

        [HttpPost]
        public ActionResult EditAllocation(Model.ProjectAllocation allocation)
        {
            new ProjectAllocationBC().UpdateProjectAllocation(allocation);
            return RedirectToAction("ProjectAllocation");
        }

        [HttpPost]
        public ActionResult DeleteAllocation(int id)
        {
            var result = new ProjectAllocationBC().DeleteProjectAllocation(id);
            //return Json(result, JsonRequestBehavior.AllowGet);
            return RedirectToAction("ProjectAllocation");
        }
        #endregion
    }
}
