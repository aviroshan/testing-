﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />
/// <reference path="D:\Avinash\MD\Karthik latest\Master Dashboard - Copy\MasterDashboard.WebUI\Scripts/angular.js" />
/// <reference path="D:\Avinash\MD\Karthik latest\Master Dashboard - Copy\MasterDashboard.WebUI\Scripts/angular.min.js" />



app.controller("ReportsController", function ($scope, $rootScope, appSettings, apiService, $filter) {
    /*-----------------Alert Modal Variables and Data loading---------------------------*/
    $scope.data_waiting = true;
    $scope.showAlertMesage = false;
    $scope.successMessage = false;
    $scope.errorMessage = false;

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Reports";
    $rootScope.MasterConstant.ShortTitle = "Reports Home";

    $scope.SubItems = [];
    
    GetSubItems();

    function GetSubItems() {
        var data = {};
        apiService.get(appSettings.getReportSubItems, data).then(function (projectData) {
            $scope.SubItems = projectData.data;
        }, function () {
            alert('Error occured');
        });
    };

    /** Reports Dialog - Start **/
    $scope.showWSRDialog = function () {
        $scope.WSRReportsDialog = true;
    };

    $scope.closeWSRDialog = function () {
        $scope.WSRReportsDialog = false;
        $scope.rptReportType = "--Select--";
        $scope.ReportTypeError = false;
        $scope.data_waiting = false;
    };

    $scope.generateWSR = function () {
        $scope.rptReportType = "Excel";
        var IsValidated = true;
        if ($scope.rptReportType == "--Select--") {
            $scope.ReportTypeError = true;
            IsValidated = false;
        }
        else {
            $scope.ReportTypeError = false;
            //Generate Report
            if (IsValidated) {
                $scope.data_waiting = true;
                var data = {};
                if ($scope.rptReportType == "Excel")
                    data.reportType = "EXCELOPENXML";
                else
                    data.reportType = "PDF";

                data.userId = "sekark";
                data.selectedDate = new Date();

                apiService.createBinary(appSettings.getWSRReport, data).then(function (res) {
                    if (res) {
                        $scope.data_waiting = false;
                        if (data.reportType === 'EXCELOPENXML') {
                            var blob = new Blob([res.data], {
                                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
                            });
                            saveAs(blob, "TruckstopReportByRegions" + ".xlsx");
                        }
                        else if (data.reportType === 'PDF') {
                            var blob1 = new Blob([res.data], {
                                type: "application/pdf"
                            });
                            saveAs(blob1, "TruckstopReportByRegions" + ".pdf");
                        }
                        $scope.WSRReportsDialog = false;
                        $scope.rptReportType = "--Select--";
                        $scope.ReportTypeError = false;
                    }
                },
                function (response) {
                    $scope.WSRReportsDialog = false;
                    $scope.rptReportType = "--Select--";
                    $scope.ReportTypeError = false;
                    var message = GetUserMessage($scope.ReportsError, "error", "Truckstop Report ");
                    SetModalPropertyOnException($scope, message);
                });
            }
        }
    };

    $scope.$watch('rptReportType', function (newValue) {
        if ($scope.ReportTypeError == true) {
            if ($scope.rptReportType != "--Select--")
                $scope.ReportTypeError = false;
        }
    });
    /** Reports Dialog - End **/

});