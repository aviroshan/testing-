﻿using MasterDashboard.BC;
using MasterDashboard.WebUI.Reports;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using MasterDashboard.Model;
using ClosedXML.Excel;
using System.Data;
using MasterDashboard.Entity;
using Microsoft.Ajax.Utilities;

namespace MasterDashboard.WebUI.Areas.Reports.Controllers
{
    public class ReportsController : Controller
    {
        private MasterDashboardDBEntities db = new MasterDashboardDBEntities();
        // GET: Reports/Reports
        public ActionResult Index()
        {
            return View();
        }
        #region SimpleReport
        public ActionResult SimpleReport()
        {
            //return View();
            Model.ReportInput reportInput = new Model.ReportInput();
            //ViewBag.AllocationTypes = new SelectList(new ProjectAllocationTypeBC().GetAllProjectAllocationTypes(), "AllocationTypeID", "AllocationTypeName", 1);
            var allProjects = new ProjectBC().GetProjects();
            allProjects.Insert(0, new Model.Project()
            {
                ProjectID = 0,
                ProjectName = "--All--"
            });
            ViewBag.Projects = new SelectList(allProjects, "ProjectID", "ProjectName", 1);          
            return View(reportInput);
        }

        [HttpPost]
        public FileResult Export(ReportInput model)
        {

            ReportInput rp = new ReportInput();
            var projects = db.Projects.ToList();
            var pro = model.ProjectID;

            rp.StartDate = model.StartDate.Date;
            rp.EndDate = model.EndDate.Date;
            int duration = (int)(rp.StartDate - rp.EndDate).TotalDays;

            DataTable dt = new DataTable("Grid");
            dt.Columns.AddRange(new DataColumn[5] { new DataColumn("Name"),
                                            new DataColumn("Project"),
                                            new DataColumn("Rate($/hr)"),
                                            new DataColumn("Hours"),
                                            new DataColumn("Total Amount"),
                                            //new DataColumn("Project Name"),
                                            //new DataColumn("User Name")
            });

            var customers = from customer in db.Activities.ToList()
                            select customer;
            var customerRate = db.ProjectAllocations.ToList();

            var activityData = new List<ReportDataModel>();

            using (var ctx = new MasterDashboardDBEntities())
            {
                if (pro != 0)
                {
                    activityData = (from x in db.Activities.Where(a => a.DateValue >= rp.StartDate && a.DateValue <= rp.EndDate && a.ProjectId == pro)
                                    from y in db.ProjectAllocations.Where(r => r.ProjectAllocationID == x.ProjectAllocationId)
                                    from z in db.Projects.Where(m => m.ProjectID == x.ProjectId)
                                    from a in db.UserProfiles.Where(n => n.UserId == x.UserId)
                                    group new { x.UserId, x.ProjectId, x.Hours, y.Rate, z.ProjectName, a.Name } by new { x.UserId, x.ProjectId } into g
                                    select new ReportDataModel()
                                    {
                                        UserID = g.Key.UserId,
                                        ProjectID = g.Key.ProjectId,
                                        Rate = g.Select(x => x.Rate).FirstOrDefault(),
                                        Hours = g.Sum(t => t.Hours),
                                        ProjectName = g.Select(x => x.ProjectName).FirstOrDefault(),
                                        UserName = g.Select(x => x.Name).FirstOrDefault(),
                                        TotalAmount = 0
                                    }).ToList();

                    activityData.ForEach(x =>
                    {
                        x.TotalAmount = x.Hours * x.Rate.Value;
                    });
                }

                else
                {
                    activityData = (from x in db.Activities.Where(a => a.DateValue >= rp.StartDate && a.DateValue <= rp.EndDate)
                                    from y in db.ProjectAllocations.Where(r => r.ProjectAllocationID == x.ProjectAllocationId)
                                    from z in db.Projects.Where(m => m.ProjectID == x.ProjectId)
                                    from a in db.UserProfiles.Where(n => n.UserId == x.UserId)
                                    group new { x.UserId, x.ProjectId, x.Hours, y.Rate, z.ProjectName, a.Name } by new { x.UserId, x.ProjectId } into g
                                    select new ReportDataModel()
                                    {
                                        UserID = g.Key.UserId,
                                        ProjectID = g.Key.ProjectId,
                                        Rate = g.Select(x => x.Rate).FirstOrDefault(),
                                        Hours = g.Sum(t => t.Hours),
                                        ProjectName = g.Select(x => x.ProjectName).FirstOrDefault(),
                                        UserName = g.Select(x => x.Name).FirstOrDefault(),
                                        TotalAmount = 0
                                    }).ToList();
                }

                activityData.ForEach(x =>
                {
                    x.TotalAmount = x.Hours * x.Rate.Value;
                });
            }

            foreach(var activity in activityData)
            {
                dt.Rows.Add(activity.UserName, activity.ProjectName, activity.Rate, activity.Hours, activity.TotalAmount);
            }

            string fileName = "WSR from " + rp.StartDate.ToShortDateString() + " to " + rp.EndDate.ToShortDateString() + ".xlsx";

            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
                }
            }
        }
        #endregion

        [HttpGet]
        public Stream GetWSRReport(ReportBase.ReportType reportType, string userId, string selectedDate)
        {
            var truckstopReportData = GetWsrReportData(reportType, userId, selectedDate);
            return truckstopReportData;
        }

        private Stream GetWsrReportData(ReportBase.ReportType reportType, string userId, string selectedDate)
        {
            try
            {
                var wsrData = new WsrBC().GetWeekWSRData(userId, selectedDate);
                string duration = wsrData.First().DateValue.ToString("dd-MM-yy") + "-" + wsrData.Last().DateValue.ToString("dd-MM-yy");
                var fileName = "WsrReport " + duration;
                var dataSourceList = new Dictionary<string, object>();
                dataSourceList.Add("MasterDashboardDBDataSet", wsrData);

                var rdlcPath = HttpContext.Server.MapPath("~/Report/WSR/WSRReport.rdlc");

                var reportBase = new ReportBase();

                var rptParams = new Dictionary<string, string>();
                rptParams.Add("ReportDateTime", DateTime.Now.ToString());
                rptParams.Add("WeekDuration", duration);


                var outputStream = reportBase.GetReportOutputStream(rdlcPath, dataSourceList, reportType, fileName, rptParams);

                return outputStream;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public JsonResult GetReportSubItems()
        {
            var subItems = new[]{
             new{ Name = "Simple Report", Description = "Manage  & Generate Report", Click = Url.Action("SimpleReport", "Reports", new { area = "Reports" }).ToString()},

            };
            return Json(subItems, JsonRequestBehavior.AllowGet);
        }
    }

}