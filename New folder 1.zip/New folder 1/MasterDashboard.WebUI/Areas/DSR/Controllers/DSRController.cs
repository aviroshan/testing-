﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MasterDashboard.WebUI.Areas.DSR.Controllers
{
    public class DSRController : Controller
    {
        // GET: DSR/DSR
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult ViewTask()
        {
            return View();
        }

        public JsonResult GetTasksByDate(string date)
        {
            var results = new List<int>();
            DateTime selectedDate = DateTime.Parse(date);
            return Json(results, JsonRequestBehavior.AllowGet);
        }
    }
}