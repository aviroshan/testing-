﻿using System.Web.Mvc;

namespace MasterDashboard.WebUI.Areas.DSR
{
    public class DSRAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "DSR";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "DSR_default",
                "DSR/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}