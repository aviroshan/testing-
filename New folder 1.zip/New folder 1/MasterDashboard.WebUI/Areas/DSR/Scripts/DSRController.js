﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/angular.min.js" />
/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />

app.controller("DSRController", function ($scope, $filter,$rootScope, apiService, appSettings) {

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Daily Status Tracker";

    $scope.DSRItems = [];
    for (i = 1; i < 5; i++) {
       var Item = {
            Date: new Date(),
            ActualHours: i + 5 - 1,
            TruTimeHours: i + 5,
            ProjectName: "GamePlan",
            IsSelected: false
        };
        $scope.DSRItems.push(Item);
    }
    //$scope.DSRItems.push($scope.DsrSItem);
    //$scope.DSRItems.push($scope.DsrSItem);
    //$scope.DSRItems.push($scope.DsrSItem);

    $scope.SelectRow = function (dsrItem) {
        angular.forEach($scope.DSRItems, function (item) {
            item.IsSelected = false;
        });
        var selectedRow = $filter('filter')($scope.DSRItems, { Date: dsrItem.Date })[0];
        selectedRow.IsSelected = true;
    };

    function GetTasks(date) {

    }

});