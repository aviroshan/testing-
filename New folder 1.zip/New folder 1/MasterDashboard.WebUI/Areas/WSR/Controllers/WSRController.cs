﻿using MasterDashboard.BC;
using MasterDashboard.WebUI.Reports;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MasterDashboard.WebUI.Areas.WSR.Controllers
{
    public class WSRController : Controller
    {
        // GET: WSR/WSR
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetWeekWSRData(string selectedDate)
        {
            //Testing userid
            var weekItems = new WsrBC().GetWeekWSRData(@Session["UserId"].ToString(), selectedDate);
            return Json(weekItems, JsonRequestBehavior.AllowGet);
        }

        //public JsonResult UpdateWeekActivity(string activity)
        //{
        //    var newItem = JsonConvert.DeserializeObject<List<Model.Activity>>(activity);
        //    var result = new WsrBC().AddActivity(newItem);
        //    return Json(result, JsonRequestBehavior.AllowGet);
        //}

        public JsonResult AddActivity(string activity)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Activity>(activity);
            var result = new WsrBC().AddActivity(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateActivity(string activity)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Activity>(activity);
            var result = new WsrBC().UpdateActivity(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

      
    }
}