﻿using System.Web.Mvc;

namespace MasterDashboard.WebUI.Areas.WSR
{
    public class WSRAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "WSR";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "WSR_default",
                "WSR/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}