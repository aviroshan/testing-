﻿/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/angular.min.js" />
/// <reference path="C:\Karthik\Master Dashboard\MasterDashboard.WebUI\Scripts/Angular/angularModule.js" />

app.controller("WSRController", function ($scope, $rootScope, $filter, apiService, appSettings) {
    $scope.wsrItems = [];

    //Setting Page Title
    $rootScope.MasterConstant.PageTitle = "Weekly Status Tracker";
    $rootScope.MasterConstant.ShortTitle = "WSR";

    ////Initial Load - Non Saturday & Non Sunday
    //if (new Date().getDay() != 6 && new Date().getDay() != 0) {
    //    $scope.selectedDate = new Date();
    //    GetWeekData($scope.selectedDate);
    //}

    //Get WSR Table Data
    $scope.setScreenData = function () {
        GetWeekData($scope.selectedDate);
    }

    GetProjectItems();

    function GetProjectItems() {
        var data = {};
        apiService.get(appSettings.getProjects, data).then(function (projectItemsData) {
            $scope.projectItems = projectItemsData.data;
            var selectProject = { ProjectID: 0, ProjectName: '--Select--', AreaID: 0, AreaName: '' };
            $scope.projectItems.splice(0, 0, selectProject);
        }, function () {
            alert('Error occured while fetching Project Items.');
        });
    }

    $scope.loadWeekData = function () {
        var loadedDate = Date.parse($scope.selectedDate);
        if (loadedDate != null) {
            var loadScreen = true;
            if ($scope.wsrItems.length == 0) {
                loadScreen = true;
            }
            else {
                var customDate = (new Date($scope.selectedDate).getMonth() + 1) + "/" + new Date($scope.selectedDate).getDate() + "/" + new Date($scope.selectedDate).getFullYear();
                var checkDateRange = $filter('filter')($scope.wsrItems, { DateString: customDate });
                if (checkDateRange.length > 0)
                    loadScreen = false;
            }
            if (loadScreen)
                GetWeekData($scope.selectedDate);
            else
                alert('Same Date Range');
        }
    }

    function GetWeekData(date) {
        var data = {};
        data.selectedDate = date;
        apiService.get(appSettings.getWeekWSRData, data).then(function (weekData) {
            $scope.wsrItems = weekData.data;
            $scope.actualwsrItems = angular.copy($scope.wsrItems);
            $scope.periodDuration = $scope.wsrItems[0].DateString + " - " + $scope.wsrItems[$scope.wsrItems.length - 1].DateString;

            //For Cancel Functionality
            angular.forEach($scope.wsrItems, function (item) {
                item.hasChanges = false;
            });

            //Testing - Friday = Holiday
            //$scope.wsrItems[$scope.wsrItems.length - 1].IsHoliday = true;

        }, function () {
            alert('Error occured while fetching Week WSR Data.');
        });
    }

    $scope.addRow = function (wsrItem) {
        AddActivity(wsrItem)
    }

    function AddActivity(wsrItem) {
        var data = {};
        data.activity = wsrItem;
        apiService.get(appSettings.addActivity, data).then(function (activityIdData) {
            //Set wsrItems Object
            setObjectOnAddEdit(wsrItem, activityIdData.dataa);
        }, function () {
            alert('Error occured while adding Activity.');
        });
    }

    $scope.updateRow = function (wsrItem) {
        UpdateActivity(wsrItem)
    }

    function setObjectOnAddEdit(wsrItem, activityId) {
        //Set wsrItems Object
        var item = $filter('filter')($scope.wsrItems, { DateString: wsrItem.DateString })[0];
        item.ActivityId = activityId;
        item.hasChanges = false;
        item.IsHoliday = false;
        item.ProjectID = wsrItem.ProjectID;
        item.Hours = wsrItem.Hours;
        item.ProjectAllocationId = wsrItem.ProjectAllocationId;
        item.Comments = wsrItem.Comments;
    }

    function UpdateActivity(wsrItem) {
        var data = {};
        data.activity = wsrItem;
        apiService.get(appSettings.updateActivity, data).then(function (activityIdData) {
            //Set ActivityId
            setObjectOnAddEdit(wsrItem, wsrItem.ActivityId);
            UpdateActualWSRItems(wsrItem);
        }, function () {
            alert('Error occured while updating Activity.');
        });
    }

    function UpdateActualWSRItems(wsrItem) {
        //Set wsrItems Object
        var item = $filter('filter')($scope.actualwsrItems, { DateString: wsrItem.DateString })[0];
        item.ActivityId = activityId;
        item.hasChanges = false;
        item.IsHoliday = false;
        item.ProjectID = wsrItem.ProjectID;
        item.Hours = wsrItem.Hours;
        item.ProjectAllocationID = wsrItem.ProjectAllocationId;
        item.Comments = wsrItem.Comments;
    }

    $scope.cancelEdit = function(wsrItem)
    {
        var item = $filter('filter')($scope.wsrItems, { DateString: wsrItem.DateString })[0];
        var actualItem = $filter('filter')($scope.actualwsrItems, { DateString: wsrItem.DateString })[0];
        item.ProjectID = actualItem.ProjectID;
        item.Hours = actualItem.Hours;
        item.Comments = actualItem.Comments;
        item.hasChanges = false;
    }

    /* Bulk Save

    $scope.save = function () {
        var check = $scope.validate();
        if (check) {
            alert('bulk save');
        }
        else {
            alert('Invalid Record Found');
        }
    }

    $scope.validate = function () {
        var isValid = true;
        var dates = $scope.wsrItems.map(data => data.DateString);
        var uniqueDates = dates.filter((x, i, a) => x && a.indexOf(x) === i);

        angular.forEach(uniqueDates, function (item) {
            var dateItems = $filter('filter')($scope.wsrItems, { DateString: item });
            var sumHours = 0;
            if (dateItems.length == 1) {
                if(parseFloat(dateItems[0].Hours) > 12)
                {
                    isValid = false;
                    dateItems[0].errorMsg = "Maximum 12 hours.";
                    alert("Incase of overtime add using overtime.");
                }
            }
            else {
                angular.forEach(dateItems, function (dt) {
                    sumHours += dt.Hours;
                    if (sumHours > 12) {
                        isValid = false;
                        dt.errorMsg = "Maximum 12 hours.";
                        alert("Incase of overtime add using overtime.");
                    }
                });
            }
        });

        return isValid;
    }

    $scope.reset = function () {
        $scope.setScreenData();
    }
    */
});

/*Add ROws

//Add New Row
    $scope.addRow = function (index) {
        var addDate = {
            DateString: $scope.wsrItems[index].DateString,
            DateValue: new Date($scope.wsrItems[index].DateString),
            Hours: 8,
            Comments: '',
            IsParent: false
        };

        $scope.wsrItems.splice(index + 1, 0, addDate);
        $scope.setWSRDataIndex();
    }

    //Apply Row Index
    $scope.setWSRDataIndex = function () {
        for (var i = 0; i < $scope.wsrItems.length; i++) {
            $scope.wsrItems[i].Index = i;
        }
    }

    //Delete Row
    $scope.deleteRow = function (index) {
        if (!$scope.wsrItems[index].IsParent)
            $scope.wsrItems.splice(index, 1);
    }

*/