﻿using MasterDashboard.BC;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MasterDashboard.WebUI.Areas.User.Controllers
{
    public class ProfileController : Controller
    {
        // GET: User/Profile
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetUsers()
        {
            var projectItems = new UserBC().GetUsers();
            return Json(projectItems, JsonRequestBehavior.AllowGet);
        }

        public JsonResult AddArea(string area)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Area>(area);
            var result = new ProjectBC().AddArea(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult UpdateProject(string project)
        {
            var newItem = JsonConvert.DeserializeObject<Model.Project>(project);
            var result = new ProjectBC().UpdateProject(newItem);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteProject(int projectID)
        {
            var result = new ProjectBC().DeleteProject(projectID);
            return Json(result, JsonRequestBehavior.AllowGet);
        }
    }
}