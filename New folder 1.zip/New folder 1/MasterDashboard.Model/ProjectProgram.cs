﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class ProjectProgram
    {
        public int ProgramID { get; set; }
        public string ProgramName { get; set; }
        public int DomainID { get; set; }
        public string DomainName { get; set; }
    }
}
