﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class Area
    {
        public int AreaId { get; set; }
        public string AreaName { get; set; }
        public bool isActive { get; set; }
        List<User> userArea = new List<User>();
    }
}
