﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class ProjectAllocationType
    {
        public int AllocationTypeID { get; set; }
        public string AllocationTypeName { get; set; }
        public string Description { get; set; }
    }
}
