﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class Holiday
    {
        public int HolidayID { get; set; }
        public bool IsHoliday { get; set; } //Dev Purpose Only
        public DateTime DateValue { get; set; }
        public string DateString { get; set; } //Dev Purpose Only - Angular
        public int LocationID { get; set; } = -1;
        public string Comments { get; set; }
    }
}
