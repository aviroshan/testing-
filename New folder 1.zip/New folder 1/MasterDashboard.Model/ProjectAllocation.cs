﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class ProjectAllocation
    {
        public int ProjectAllocationID { get; set; }
        public string UserID { get; set; }
        public string UserName { get; set; } //Dev Purpose Only

        [Required]
        public int ProjectID { get; set; }
        public string ProjectName { get; set; } //Dev Purpose Only

        [Required]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}")]
        [DataType(DataType.Date)]
        public System.DateTime StartDate { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:d}")]
        [DataType(DataType.Date)]
        public System.DateTime EndDate { get; set; }

        [Required]
        public int AllocationTypeID { get; set; }
        public string AllocationTypeName { get; set; } //Dev Purpose Only

        public int Rate { get; set; }
    }
}
