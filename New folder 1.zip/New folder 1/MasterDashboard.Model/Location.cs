﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class Location
    {
        public int LocationID { get; set; }
        public string LocationName { get; set; }

        public bool IsHolidayConnected { get; set; } = false; //For Dev Only

        public List<Model.Holiday> Holidays { get; set; } //Dev Purpose Only
    }
}
