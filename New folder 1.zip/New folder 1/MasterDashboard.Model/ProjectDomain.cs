﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class ProjectDomain
    {
        public int DomainID { get; set; }
        public string DomainName { get; set; }
    }
}
