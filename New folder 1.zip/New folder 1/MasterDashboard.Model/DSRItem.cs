﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class DSRItem
    {
        public DateTime Date { get; set; }
        public string DateValue { get; set; } //For dev only
        public double ActualHours { get; set; }
        public double TruTimeHours { get; set; }
        public int ProjectID { get; set; }
        public Project Project { get; set; } //For dev only
        public bool IsSelected { get; set; } //For dev purpose only
    }
}
