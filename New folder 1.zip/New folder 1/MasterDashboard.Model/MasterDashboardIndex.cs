﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class MasterDashboardIndex
    {
        public string Name { get; set; }
        public string Click { get; set; }
        public List<MasterDashboardIndex> SubItems { get; set; }
        public string RoleName { get; set; }
    }
}
