﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class ReportDataModel
    {
        public string UserID { get; set; }
        public int ProjectID { get; set; }
        public int? Rate { get; set; }
        public double Hours { get; set; }
        public double TotalAmount { get; set; }
        public string UserName { get; set; }
        public string ProjectName { get; set; }
    }
}
