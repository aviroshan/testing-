﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterDashboard.Model
{
    public class Activity
    {
        public long ActivityId { get; set; }
        public string UserId { get; set; }
        public string DateString { get; set; }
        public DateTime DateValue { get; set; }
        public int ProjectID { get; set; }
        public int ProjectAllocationId { get; set; }
        public double Hours { get; set; }
        public string Comments { get; set; }
        public bool IsHoliday { get; set; }
        public string HolidayComments { get; set; }
        public bool IsApproved { get; set; }
        public bool IsManagerApproved { get; set; }
    }
}

